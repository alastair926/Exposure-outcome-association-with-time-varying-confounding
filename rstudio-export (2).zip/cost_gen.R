
# script designed to generate costs


# pf ----------------------------------------------------------------------



# alpha parameter for gamma regression
alpha <- 1.13


# pf gamma predictive -------------------------------------------

costcoefs <- c(30,	0.04,-15,30) #age 0.04


datacol <- match(c("age","male","t_0"),colnames(df))
datacol <- datacol[!is.na(datacol)]


y <- eval(parse(text= paste("costcoefs[1] + ", paste0( "costcoefs[",2:(length(datacol)+1),"]*as.numeric(as.character(df[,",datacol[1:(length(datacol))],"]))" , collapse = "+" )) ))
alpha_b <- alpha/y
#force single people generation
y.cost <- rep(NA, n)
for(i in 1:n){
  #y.cost[i] <- d[i] * rgamma(1, shape = alpha , rate = alpha_b[i])
  y.cost[i] <-  rgamma(1, shape = alpha , rate = alpha_b[i])
  
}
#y.cost <- d * rgamma(n, shape = alpha , rate = alpha_b)
summary(y.cost)

df <- cbind( df , cost.pf=y.cost)


# pp ----------------------------------------------------------------------



# alpha parameter for gamma regression
alpha <- 1.13




# pp gamma predictive -------------------------------------------

costcoefs <- c(80,0.1,-10)


datacol <- match(c("age","male"),colnames(df))
datacol <- datacol[!is.na(datacol)]


y <- eval(parse(text= paste("costcoefs[1] + ", paste0( "costcoefs[",2:(length(datacol)+1),"]*as.numeric(as.character(df[,",datacol[1:(length(datacol))],"]))" , collapse = "+" )) ))
alpha_b <- alpha/y

#force single people generation
y.cost <- rep(NA, n)
for(i in 1:n){
  #y.cost[i] <- d[i] * rgamma(1, shape = alpha , rate = alpha_b[i])
  y.cost[i] <- rgamma(1, shape = alpha , rate = alpha_b[i])
  
}

#y.cost <- d * rgamma(n, shape = alpha , rate = alpha_b)
summary(y.cost)

df <- cbind( df , cost.pp=y.cost)


# cost per day in cost in state -------------------------------------------

df <- df %>% 
  mutate(costin_pf = if_else( prog_s == 1, real_prog_t * 365.25 * cost.pf , real_dead_t * 365.25 * cost.pf )) %>% 
  mutate(costin_pp = if_else( prog_s == 1, trans_fromprogtodeath * 365.25 * cost.pp , NA_real_ )) 

summary( df %>% 
  pull(costin_pp) )
summary( df %>% 
  pull(costin_pf) )



