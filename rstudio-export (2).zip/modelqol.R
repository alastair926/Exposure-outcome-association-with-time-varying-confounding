
# model qol for observations in the pf state
qoldata <- surv_long3 %>% 
  mutate(vsttime = vst*0.5) %>% 
  filter(real_prog_t >= vsttime | is.na(real_prog_t)==T ) %>% 
  filter(real_dead_t >= vsttime | is.na(real_dead_t)==T )

# pf state
mins <- min(qoldata$eq5d_pf_,na.rm = T) # min value eq5d
maxs <- max(qoldata$eq5d_pf_[qoldata$eq5d_pf_!=1],na.rm = T) # max value any patients eq5d can take after removing index ==1s


qoldata <- qoldata %>% 
  mutate(iseq5d1 = if_else(eq5d_pf_ == 1 , 1 , 0)) %>% 
  #mutate(iseq5d1_pp_ = if_else(eq5d_pp_ == 1 , 1 , 0)) %>% 
  mutate(index_rescale = (eq5d_pf_ +abs(mins))/(maxs + abs(mins))  ) %>%
  mutate(index_adjust = if_else(index_rescale == 0 , 0.00001 ,
                                if_else(index_rescale == 1 , 0.99999 , index_rescale)))




library(lme4)
log_mod <- glmer(iseq5d1 ~ age + v_ + t_ + (1 | id) , #was id_new (studyID:arm_esa)
                 data = qoldata, family = binomial, control = glmerControl(optimizer = "bobyqa"),
                 nAGQ = 10,weights =`iptw`)

#install.packages("glmmTMB")
library(glmmTMB)

beta_mod <- glmmTMB(
  index_adjust ~ age + v_ + t_ +(1 | id) ,  #was id_new (studyID:arm_esa)
  family=beta_family,data=qoldata %>% filter(iseq5d1==0),weights = iptw)

save(log_mod,beta_mod,file="qol_models.RData")

# pp ----------------------------------------------------------------------


# model qol
qoldata <- surv_long3 %>% 
  mutate(vsttime = vst*0.5) %>% 
  filter(real_prog_t <= vsttime | is.na(real_prog_t)==T ) %>% 
  filter(real_dead_t >= vsttime | is.na(real_dead_t)==T )

# pf state
mins <- min(qoldata$eq5d_pp_,na.rm = T) # min value eq5d
maxs <- max(qoldata$eq5d_pp_[qoldata$eq5d_pp_!=1],na.rm = T) # max value any patients eq5d can take after removing index ==1s


qoldata <- qoldata %>% 
  mutate(iseq5d1 = if_else(eq5d_pp_ == 1 , 1 , 0)) %>% 
  #mutate(iseq5d1_pp_ = if_else(eq5d_pp_ == 1 , 1 , 0)) %>% 
  mutate(index_rescale = (eq5d_pp_ +abs(mins))/(maxs + abs(mins))  ) %>%
  mutate(index_adjust = if_else(index_rescale == 0 , 0.00001 ,
                                if_else(index_rescale == 1 , 0.99999 , index_rescale)))




library(lme4)
log_mod <- glmer(iseq5d1 ~ age + v_ + t_ + (1 | id) , #was id_new (studyID:arm_esa)
                 data = qoldata, family = binomial, control = glmerControl(optimizer = "bobyqa"),
                 nAGQ = 10,weights =`iptw`)

#install.packages("glmmTMB")
library(glmmTMB)

beta_mod <- glmmTMB(
  index_adjust ~ age + v_ + t_ + (1 | id) ,  #was id_new (studyID:arm_esa)
  family=beta_family,data=qoldata %>% filter(iseq5d1==0),weights = iptw)


save(log_mod,beta_mod,file="qol_models_pp.RData")

