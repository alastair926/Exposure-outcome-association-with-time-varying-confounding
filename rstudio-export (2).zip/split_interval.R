
# to death
transdeath <- alltransdata %>% filter(trans==2)


t_events<-sort(unique(transdeath$Tstop))
times<-data.frame("tevent"=t_events,"ID_t"=seq(1:length(t_events)))


splitdeath <- survSplit(transdeath, cut=t_events, end="Tstop", 
                     start="Tstart", event="status",id="ID") 
splitdeath<-splitdeath[order(splitdeath$ID,splitdeath$Tstop ),] 


# to prog
transdata <- alltransdata %>% filter(trans==1)


t_events<-sort(unique(transdata$Tstop))
times<-data.frame("tevent"=t_events,"ID_t"=seq(1:length(t_events)))


splitdata <- survSplit(transdata, cut=t_events, end="Tstop", 
                     start="Tstart", event="status",id="ID") 
splitdata<-splitdata[order(splitdata$ID,splitdata$Tstop ),] 


# combine status columns into one data with clear names
splitdata$status_p <-splitdata$status
splitdata$status_d <-splitdeath$status

head(splitdata %>% select(id,Tstart,Tstop,status_p,status_d,status) )


save(splitdata,file = "splitdata.RData")
