


w <- ipwtm(exposure = t_, family = "binomial",
              link = "logit",
              numerator = ~ age + male  ,
              denominator = ~ age + male + v_,
              id = id,
               timevar = Tstop, type = "first", data = as.data.frame(tevents_dat))


iptw = w$ipw.weights

tevents_weights <- cbind(tevents_dat, iptw)


ipwplot(weights = tevents_weights$iptw, 
        timevar = as.numeric(tevents_weights$Tstop), 
        binwidth = 0.5,
        main = "Stabilized weights", 
        # xaxt = "n",
        # yaxt = "n",
        xlab = "Every 6 months",
        ylab = "Log(Weights)")

# adjust log(weights) over 4/below -4
tevents_weights <- tevents_weights %>% 
  mutate(log_w = log(iptw)) %>% 
  mutate(log_w_adj = if_else( log_w > 4 , 4, 
                      if_else( log_w < -4 , -4 , log_w  ))) %>% 
  mutate(iptw = exp(log_w_adj)) 


ipwplot(weights = tevents_weights$iptw, 
        timevar = as.numeric(tevents_weights$Tstop), 
        binwidth = 0.5,
        main = "Stabilized weights", 
        # xaxt = "n",
        # yaxt = "n",
        xlab = "Every 6 months",
        ylab = "Log(Weights)")

save(tevents_weights,file="tevents_weights.RData")
