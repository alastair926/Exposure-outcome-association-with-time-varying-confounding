




# loop gen qol pf state  -----------------------------------------------------------
# gen eq5d at every time point - need for LTMLE and do analysis on 

colnames(df)

l_cov_dat <- data.frame(var1=rep("age",timepoints))
l_cov_dat <- l_cov_dat %>% mutate(var2 =  paste0( "v_",seq(0,timepoints-1)) )

b_cov_dat <- data.frame(var1=rep("age",timepoints))
b_cov_dat <- b_cov_dat %>% mutate(var2 =  paste0( "v_",seq(0,timepoints-1)) )

#coefs <- c(-0.32,-1.1 ,  1 )
coefs_dat <- data.frame(coef1= rep(0.32,timepoints) )
coefs_dat <- coefs_dat %>% mutate(coef2 = -0.15)
coefs_dat <- coefs_dat %>% mutate(coef3 = 1)
#coefs <- c(1.17,-0.015 , 0.003 )
coefs_dat_b <- data.frame(coef1= rep(1.17,timepoints) )
coefs_dat_b <- coefs_dat_b %>% mutate(coef2 = -0.015)
coefs_dat_b <- coefs_dat_b %>% mutate(coef3 = 0.09)
mins <- -0.2809753 # min eq5d value
maxs <- 1 # max eq5d value any patients can take
phi <- 6
eq5d_tp_dat <- data.frame(matrix(ncol = timepoints,nrow = nrow(df) ))

for(i in 1:timepoints){
  y <- eval(parse(text= paste("coefs_dat[",i,",1] + ", paste0( "coefs_dat[",i,",",2:(ncol(l_cov_dat)+1),"]*as.numeric(as.character(df$",unlist(l_cov_dat[i,1:ncol(l_cov_dat)]),"))" , collapse = "+" )) ))
  l_prob <- exp(y)/ (1 + exp(y))  
  d <- rbinom(nrow(df),1,l_prob)

  y <- eval(parse(text= paste("coefs_dat_b[",i,",1] + ", paste0( "coefs_dat_b[",i,",",2:(ncol(b_cov_dat)+1),"]*as.numeric(as.character(df$",unlist(b_cov_dat[i,1:(length(b_cov_dat))]),"))" , collapse = "+" )) ))
  b_pred <- exp(y)/ (1 + exp(y))
  
  a <- b_pred * phi
  b <- (1 - b_pred) * phi
  
  b_sim <- rbeta(nrow(df),a,b)  # generate back to patient dist (beta scale) using cmean and aux parameters
  b_sim <- (b_sim*(maxs-mins))+mins  #transform b_pred back to eq5d scale
  c_eq5d  <- ((1-d)*b_sim) + d   # exp val formula on utility - combines logistic and beta
  eq5d_tp_dat[,i] <- c_eq5d
}

colnames(eq5d_tp_dat) <- paste0("eq5d_pf_",seq(0,timepoints-1))
df <- cbind(df,eq5d_tp_dat)

# then do pp state
# loop gen qol pp state  -----------------------------------------------------------
# gen eq5d at every time point - need for LTMLE and do analysis on 

colnames(df)

l_cov_dat <- data.frame(var1=rep("age",timepoints))
l_cov_dat <- l_cov_dat %>% mutate(var2 =  paste0( "v_",seq(0,timepoints-1)) )

b_cov_dat <- data.frame(var1=rep("age",timepoints))
b_cov_dat <- b_cov_dat %>% mutate(var2 =  paste0( "v_",seq(0,timepoints-1)) )


coefs_dat <- data.frame(coef1= rep(0.32,timepoints) )
coefs_dat <- coefs_dat %>% mutate(coef2 = -0.18)
coefs_dat <- coefs_dat %>% mutate(coef3 = 1)

coefs_dat_b <- data.frame(coef1= rep(1.17,timepoints) )
coefs_dat_b <- coefs_dat_b %>% mutate(coef2 = -0.02)
coefs_dat_b <- coefs_dat_b %>% mutate(coef3 = 0.08)
mins <- -0.2809753 # min eq5d value in t.index lookup table
maxs <- 1 # max eq5d value any patients eq5d can take
phi <- 6
eq5d_tp_dat <- data.frame(matrix(ncol = timepoints,nrow = nrow(df) ))

for(i in 1:timepoints){
  y <- eval(parse(text= paste("coefs_dat[",i,",1] + ", paste0( "coefs_dat[",i,",",2:(ncol(l_cov_dat)+1),"]*as.numeric(as.character(df$",unlist(l_cov_dat[i,1:ncol(l_cov_dat)]),"))" , collapse = "+" )) ))
  l_prob <- exp(y)/ (1 + exp(y))  
  d <- rbinom(nrow(df),1,l_prob)
  table(d)
  
  y <- eval(parse(text= paste("coefs_dat_b[",i,",1] + ", paste0( "coefs_dat_b[",i,",",2:(ncol(b_cov_dat)+1),"]*as.numeric(as.character(df$",unlist(b_cov_dat[i,1:(length(b_cov_dat))]),"))" , collapse = "+" )) ))
  b_pred <- exp(y)/ (1 + exp(y))
  
  a <- b_pred * phi
  b <- (1 - b_pred) * phi
  
  b_sim <- rbeta(nrow(df),a,b)  # generate back to patient dist (beta scale) using cmean and aux parameters
  b_sim <- (b_sim*(maxs-mins))+mins  #transform b_pred back to eq5d scale
  c_eq5d  <- ((1-d)*b_sim) + d   # exp val formula on utility - combines logistic and beta
  eq5d_tp_dat[,i] <- c_eq5d
  summary(c_eq5d)
}
colnames(eq5d_tp_dat) <- paste0("eq5d_pp_",seq(0,timepoints-1))
df <- cbind(df,eq5d_tp_dat)


