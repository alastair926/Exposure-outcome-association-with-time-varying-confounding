


# plot --------------------------------------------------------------------



plot(survfit(Surv(real_dead_t,dead_s) ~ 1,
             data = df))
plot(survfit(Surv(real_dead_t,dead_s) ~ t_0,
             data = df))


survmodtx_0 <- survfit(Surv(real_dead_t,dead_s) ~ 1,
                       data = df %>% filter(t_0==0))
survmodtx_1 <- survfit(Surv(real_dead_t,dead_s) ~ 1,
                       data = df %>% filter(t_0==1))

t <- seq(0,3.5,by=0.1)
#unadj_surv <- summary(survmodtx,times = t)
unadj_surv_0 <- summary(survmodtx_0,times = t)
unadj_surv_1 <- summary(survmodtx_1,times = t)
ggplot()+
  geom_line(aes(x=unadj_surv_0$time,y=unadj_surv_0$surv),colour="red") +
  geom_line(aes(x=unadj_surv_1$time,y=unadj_surv_1$surv),colour="blue") 


# long data ---------------------------------------------------------------


colnames(df)


substrRight <- function(x, n){
  substr(x, nchar(x)-n+1, nchar(x))
}


# for pivot to work - must end with _0, _1, _2 - this is what regular expressions\ is looking for
# tv on vst ending with _vstno
surv_long <- df %>% select(id,age,male,prog_s,real_prog_t,dead_s,real_dead_t,
                           paste0("t_",0:(timepoints-1)),paste0("v_",0:(timepoints-1) ) ,
                           costin_pf,costin_pp,cost.pf,cost.pp,
                           paste0("eq5d_pf_",0:(timepoints-1) ), paste0("eq5d_pp_",0:(timepoints-1) ) ) %>% 
  # eq5d in states
  #paste0("eq5d_pf_",seq(0,timepoints-1)),paste0("eq5d_pp_",seq(0,timepoints-1)) ) %>% 
  pivot_longer(
    cols = starts_with("t_") | starts_with("v_")  | starts_with("eq5d_pf_")  | starts_with("eq5d_pp_"),   #| starts_with("eq5d_"),
    names_to = c(".value", "group"),
    names_pattern = "(\\w+_)(\\w+)"
  ) %>% 
  mutate(vst = group) %>% select(-c(group))


surv_long2 <- surv_long %>% 
  mutate(flag = if_else( (vst==1 & real_dead_t<fup_array[2]) |
                           (vst==2 & real_dead_t<fup_array[3]) |
                           (vst==3 & real_dead_t<fup_array[4]) |
                           (vst==4 & real_dead_t<fup_array[5]) |
                           (vst==5 & real_dead_t<fup_array[6]) |
                           (vst==6 & real_dead_t<fup_array[7]) |
                           (vst==7 & real_dead_t<fup_array[8]) 
                         , 1 , 0 )) %>% 
  filter(flag==0)





save(surv_long2,file = "surv_long2.RData")


