



trans3dat <- alltransdata %>% filter(trans==3)

nrow(trans3dat)
trans3dat <- merge(trans3dat,surv_wide %>% select(id,v_0=v__0) ,by="id")
nrow(trans3dat)

# no need to compare tx groups for trans 3 - both tx groups share same curve
survmod <- survfit(Surv(time,status) ~ 1,
                       data = trans3dat )


t <- seq(0,3.5,by=0.1)
surv_3 <- summary(survmod,times = t)

ggplot()+
  geom_line(aes(x=surv_3$time,y=surv_3$surv),colour="red") 


trans3_mod <- flexsurvreg(Surv(time,status)~age,data=trans3dat,dist = "weibull")

save(trans3_mod,file="trans3model.RData")

t <- seq(0,10,by=0.01)

extra_3 <- summary(trans3_mod,times = t)[[1]]

# extrapolate
# trans from prog to death

plt <- ggplot()+
  geom_line(aes(x=surv_3$time,y=surv_3$surv),size= 4,alpha=0.7,colour="azure4") +
  geom_line(aes(x=extra_3$time,y=extra_3$est),size= 2.7,alpha=0.9,colour="black") +
  theme(text = element_text(size=50)) +
  labs(y = "survival",x = "years") 
ggsave(plt,file="progtodeath_extrapolate.png", width =  600, height = 290 , units = "mm", dpi = 300)  




