
# main 
# start -------------------------------------------------------------------



# clear data
rm(list=ls())
library(ipw)
library(geepack)
library(flexsurv)
library(mstate)
library(tidyverse)

# generate dat ------------------------------------------------------------

#source("my_tvc_data.R")
source("my_tvc_data2.R") # try harsher surv
# output: df

summary(df)
# eq5d generate -----------------------------------------------------------


source("eq5d_gen.R")
# output: df

# cost generate -----------------------------------------------------------

# ignore script - cost analysis not performed
source("cost_gen.R")
# output: df

# long data conversion -----------------------------------------------------------


source("longconversion.R")
# output: surv_long2


# inspect vars ------------------------------------------------------------


source("inspect_variables.R")


# MSM for overall surv ---------------------------------------------------------------------
# use IPTW

# produces teatment effect est on overall surv
load(file = "surv_long2.RData")




surv_long2$vst <- as.numeric(surv_long2$vst)

w <- ipwtm(
  exposure = t_,
  family = "binomial",
  link = "logit",
  numerator = ~  age + male,
  denominator = ~  v_ + age + male,
  id = id,
  timevar=vst,
  type="first",
  data = as.data.frame(surv_long2))

iptw = w$ipw.weights

surv_long3 <- cbind(surv_long2, iptw)


ipwplot(weights = surv_long3$iptw, 
        timevar = as.numeric(surv_long3$vst), 
        binwidth = 1,
        main = "Stabilized weights",
        xlab= "Every 6 months",
        ylab = "log(weights)")
        # xaxt = "n",
        # yaxt = "n")


save(surv_long3,file="surv_long3.RData")


# MSM for qol ATE
summary(geeglm(eq5d_pf_~t_ + vst  + age + v_ + cluster(id),
                   id=id,
                   data=surv_long3, 
                   family=gaussian("identity"), 
                   corstr="ar1",
                   weights = iptw))

# unajusted for ATE qol
summary(geeglm(eq5d_pf_~t_ + vst  + age + v_ + cluster(id),
                   id=id,
                   data=surv_long3, 
                   family=gaussian("identity"), 
                   corstr="ar1"))

# msprep ------------------------------------------------------------------
# for multi state modelling - need to analyse transtions
# msprep readies data for MSModelling
load(file = "surv_long3.RData")

source("msprep.R")
# output : alltransdata


# overall ATE -------------------------------------------------------------


source("overallsurvATE.R")

# split time intervals ----------------------------------------------------
# need to split data into time intervals so that time varying covariates can be used

load("alltransdata.RData")
source("split_interval.R")
# output: splitdata


# add baseline & time varying covariates ---------------------------------------------

load("splitdata.RData")
load(file = "surv_long3.RData")
source("timevaryingcov.R")
# output: tevents_dat

head(tevents_dat)

# weights -----------------------------------------------------------------

load("tevent_dat.RData")
source("weights.R")
# output: tevents_weights


# plot trans --------------------------------------------------------------



# adjusted weighted - trans to death only (NOT OVERALL SURV)
survmodtx_0 <- survfit(Surv(Tstart,Tstop,status_d) ~ 1,
                       data = tevents_weights %>% filter(t_==0),weights = iptw)
survmodtx_1 <- survfit(Surv(Tstart,Tstop,status_d) ~ 1,
                       data = tevents_weights %>% filter(t_==1),weights = iptw)

t <- seq(0,3.5,by=0.1)
#unadj_surv <- summary(survmodtx,times = t)
adj_surv_0 <- summary(survmodtx_0,times = t)
adj_surv_1 <- summary(survmodtx_1,times = t)
ggplot()+
  geom_line(aes(x=adj_surv_0$time,y=adj_surv_0$surv),colour="red") +
  geom_line(aes(x=adj_surv_1$time,y=adj_surv_1$surv),colour="blue") 


# adjusted weighted - trans to prog
survmodtx_0 <- survfit(Surv(Tstart,Tstop,status_p) ~ 1,
                       data = tevents_weights %>% filter(t_==0),weights = iptw)
survmodtx_1 <- survfit(Surv(Tstart,Tstop,status_p) ~ 1,
                       data = tevents_weights %>% filter(t_==1),weights = iptw)

t <- seq(0,3.5,by=0.1)
#unadj_surv <- summary(survmodtx,times = t)
adj_surv_0 <- summary(survmodtx_0,times = t)
adj_surv_1 <- summary(survmodtx_1,times = t)
ggplot()+
  geom_line(aes(x=adj_surv_0$time,y=adj_surv_0$surv),colour="red") +
  geom_line(aes(x=adj_surv_1$time,y=adj_surv_1$surv),colour="blue") 


# flexsurv trans1&2 ----------------------------------------------------------------

source("flexsurv.R")
#transitionmodels.RData

# trans 3 - from prog to death --------------------------------------------

load("alltransdata.RData")
alltransdata
source("trans3.R")
#trans3model.RData


# extrapolate weighted KM -------------------------------------------------

source("extrapolations.R")


# model eq5d --------------------------------------------------------------

load(file="surv_long3.RData")
surv_long3
source("modelqol.R")

# model costs --------------------------------------------------------------

# ignore - cost analysis not performed
# load(file="surv_long3.RData")
# surv_long3
# source("modelcost.R")




