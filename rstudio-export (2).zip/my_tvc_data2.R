



#set seed to replicate results
set.seed(12345)

#define sample size
n <- 2000

#define confounder male 
male <- rbinom(n,1,0.55)

#define confounder (age)
age <- 100-exp(rnorm(n, 3, 0.4))

#define tme-varying confounder v1 as a function of t1 and d1
v_0 <- rnorm(n, 9, sqrt(runif(n,min = 0,max = 1)))


#define treatment at time 0
treatment_prob <- 1 / (1 + exp(-(3.5 + 0.5 * male - 0.1 * age + 0.4 * v_0)))
summary(treatment_prob)
t_0 <- rbinom(n,1,treatment_prob)

#define time-varying confounder 
v_1 <- 0.4*t_0 - 0.1*v_0 + rnorm(n, 9.1, sqrt(runif(n,min = 0,max = 1)))

treatment_prob <- 1 / (1 + exp(-(3.5 + 0.5 * male - 0.1 * age + 0.4 * v_1 + 0.9 * t_0)))
summary(treatment_prob)
t_1 <- rbinom(n,1,treatment_prob)

#define tme-varying confounder v2
v_2 <- 0.4*t_1 - 0.1*v_1 + rnorm(n, 9.2, sqrt(runif(n,min = 0,max = 1)))

treatment_prob <- 1 / (1 + exp(-(3.5 + 0.5 * male - 0.1 * age + 0.4 * v_2 + 0.9 * t_1)))
summary(treatment_prob)
t_2 <- rbinom(n,1,treatment_prob)

#define tme-varying confounder v2
v_2 <- 0.4*t_1 - 0.1*v_1 + rnorm(n, 9.3, sqrt(runif(n,min = 0,max = 1)))

treatment_prob <- 1 / (1 + exp(-(3.5 + 0.5 * male - 0.1 * age + 0.4 * v_2 + 0.9 * t_1)))
summary(treatment_prob)
t_2 <- rbinom(n,1,treatment_prob)


#define tme-varying confounder v2
v_3 <- 0.4*t_2 - 0.1*v_2 + rnorm(n, 9.3, sqrt(runif(n,min = 0,max = 1)))

treatment_prob <- 1 / (1 + exp(-(3.5 + 0.5 * male - 0.1 * age + 0.4 * v_3 + 0.9 * t_2)))
summary(treatment_prob)
t_3 <- rbinom(n,1,treatment_prob)

#define tme-varying confounder v2
v_4 <- 0.4*t_3 - 0.1*v_3 + rnorm(n, 9.4, sqrt(runif(n,min = 0,max = 1)))

treatment_prob <- 1 / (1 + exp(-(3.5 + 0.5 * male - 0.1 * age + 0.4 * v_4 + 0.9 * t_3)))
summary(treatment_prob)
t_4 <- rbinom(n,1,treatment_prob)

#define tme-varying confounder v2
v_5 <- 0.4*t_4 - 0.1*v_4 + rnorm(n, 9.4, sqrt(runif(n,min = 0,max = 1)))

treatment_prob <- 1 / (1 + exp(-(3.5 + 0.5 * male - 0.1 * age + 0.4 * v_5 + 0.9 * t_4)))
summary(treatment_prob)
t_5 <- rbinom(n,1,treatment_prob)

#define tme-varying confounder v2
v_6 <- 0.4*t_5 - 0.1*v_5 + rnorm(n, 9.5, sqrt(runif(n,min = 0,max = 1)))

treatment_prob <- 1 / (1 + exp(-(3.5 + 0.5 * male - 0.1 * age + 0.4 * v_6 + 0.9 * t_5)))
summary(treatment_prob)
t_6 <- rbinom(n,1,treatment_prob)

#define tme-varying confounder v2
v_7 <- 0.4*t_6 - 0.1*v_6 + rnorm(n, 9.5, sqrt(runif(n,min = 0,max = 1)))

treatment_prob <- 1 / (1 + exp(-(3.5 + 0.5 * male - 0.1 * age + 0.4 * v_7 + 0.9 * t_6)))
summary(treatment_prob)
t_7 <- rbinom(n,1,treatment_prob)


df <- data.frame(age,male,
                 t_0,t_1,t_2,t_3,t_4,t_5,t_6,t_7,
                 v_0,v_1,v_2,v_3,v_4,v_5,v_6,v_7
                 )

summary(df %>% filter(t_0==1) %>% pull(v_1))
summary(df %>% filter(t_0==0) %>% pull(v_1))
summary(df %>% filter(t_1==1) %>% pull(v_2))
summary(df %>% filter(t_1==0) %>% pull(v_2))
summary(df %>% filter(t_2==1) %>% pull(v_3))
summary(df %>% filter(t_2==0) %>% pull(v_3))
summary(df %>% filter(t_3==1) %>% pull(v_4))
summary(df %>% filter(t_3==0) %>% pull(v_4))
summary(df %>% filter(t_4==1) %>% pull(v_5))
summary(df %>% filter(t_4==0) %>% pull(v_5))

summary(df %>% filter(t_0==1) %>% pull(v_1))
summary(df %>% filter(t_1==1) %>% pull(v_2))
summary(df %>% filter(t_2==1) %>% pull(v_3))
summary(df %>% filter(t_3==1) %>% pull(v_4))
summary(df %>% filter(t_4==1) %>% pull(v_5))
summary(df %>% filter(t_5==1) %>% pull(v_6))



trans_toprog_a <- rep(NA,1,n)
trans_todeath_a <- rep(NA,1,n)
trans_fromprogtodeath_a <- rep(NA,1,n)
for(i in 1:n){
  trans_toprog_a[i] <- rweibull(n = 1, scale = exp(0.01+
                                                0.01*age[i]+
                                                  0.4*t_0[i]+ #0.4
                                                0.1*v_0[i]),
                           shape = 1/exp(0.01))
  trans_todeath_a[i] <- rweibull(n = 1, scale = exp(0.01+
                                                  -0.001*age[i]+
                                                  0.5*male[i]+
                                                    0.1*v_0[i]),
                            shape = 1/exp(0.02))
  trans_fromprogtodeath_a[i] <- rweibull(n = 1, scale = exp(0.01+
                                                             0.002*age[i]), #0.005*v_0
                                       shape = 1/exp(0.05))
  

}



summary(trans_todeath_a)
summary(trans_toprog_a)
summary(trans_fromprogtodeath_a)

df <- cbind(df,trans_toprog=trans_toprog_a)
df <- cbind(df,trans_todeath=trans_todeath_a)
df <- cbind(df,trans_fromprogtodeath=trans_fromprogtodeath_a)

summary(df %>% filter(t_1==0) %>% pull(trans_toprog))
summary(df %>% filter(t_1==1) %>% pull(trans_toprog))

summary(df %>% filter(t_1==0) %>% pull(trans_todeath))
summary(df %>% filter(t_1==1) %>% pull(trans_todeath))
  
# first half a year sort
timeinterval <- 0.5
fup_array <- seq(0,5,timeinterval)
timepoints <- 8
where_array <- paste0("whereat_t",1:timepoints)
df[where_array] <- NA



df <- df %>% 
  # 1 is pf, 2 is pp, 3 is death
  mutate(whereat_t1 = if_else( trans_toprog < trans_todeath & trans_toprog < fup_array[2] & (trans_toprog + trans_fromprogtodeath) <= fup_array[2] , 3 ,
                      if_else( trans_toprog < trans_todeath & trans_toprog < fup_array[2] & (trans_toprog + trans_fromprogtodeath) > fup_array[2] , 2 ,
                      if_else( trans_toprog > trans_todeath & trans_todeath <= fup_array[2] , 3 ,
                      if_else( trans_toprog > trans_todeath & trans_todeath > fup_array[2] , 1 ,
                      if_else( trans_todeath > fup_array[2] & trans_toprog > fup_array[2] , 1 , 0
                               )))))) %>% 
  # finalise dead, prog state for those reach it at this time point
  mutate(dead_s = if_else( whereat_t1 == 3 & trans_todeath < trans_toprog , 1 ,
                  if_else( whereat_t1 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < fup_array[2] , 1 , 0
                           ))) %>% 
  mutate(dead_t = if_else( whereat_t1 == 3 & trans_todeath < trans_toprog , trans_todeath ,
                  if_else( whereat_t1 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < fup_array[2] , (trans_toprog + trans_fromprogtodeath) , NA_real_
                           ))) %>%
  
  mutate(prog_s = if_else( whereat_t1 == 2 & trans_toprog < trans_todeath & trans_toprog < fup_array[2] , 1 ,
                  if_else( whereat_t1 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < fup_array[2] , 1 , 0
                           ))) %>% 
  mutate(prog_t = if_else( whereat_t1 == 2 & trans_toprog < trans_todeath & trans_toprog < fup_array[2] , trans_toprog ,
                  if_else( whereat_t1 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < fup_array[2] , (trans_toprog ) , NA_real_
                           ))) %>% 
  mutate(id = seq(1:n)) %>% 
  # remaining prog time
  mutate(trans_remaininprog = if_else( whereat_t1 == 2 , trans_toprog + trans_fromprogtodeath - fup_array[2] , NA_real_))
 
remainingprogtimearray <- df$trans_remaininprog

df


# tp2 -------------------------------------------------------------------------

trans_toprog_a <- rep(NA,1,n)
trans_todeath_a <- rep(NA,1,n)
trans_fromprogtodeath_a <- df$trans_fromprogtodeath
for(i in 1:n){
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[1])) ) == 2 & remainingprogtimearray[i] <= timeinterval ){
    trans_fromprogtodeath_a[i] <- df$trans_toprog[i] + df$trans_fromprogtodeath[i] - fup_array[2]   
  } 
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[1])) ) == 2 & remainingprogtimearray[i] > timeinterval ){
    trans_fromprogtodeath_a[i] <- df$trans_fromprogtodeath[i] - fup_array[2]   
  } 
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[1])) ) ==1 ){
    
    trans_toprog_a[i] <- rweibull(n = 1, scale = exp(0.01+
                                                       0.01*age[i]+
                                                       0.4*t_1[i]+
                                                       0.1*v_1[i]),
                                  shape = 1/exp(0.01))
    trans_todeath_a[i] <- rweibull(n = 1, scale = exp(0.01+
                                                         -0.001*age[i]+
                                                         0.5*male[i]+
                                                        0.1*v_1[i]),
                                   shape = 1/exp(0.02))

  }# end if 

  
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[1])) ) == 3 ){
    trans_todeath_a[i] <- NA_real_
    trans_toprog_a[i] <- NA_real_
  }
}


df <- df %>% 
  mutate(trans_toprog = trans_toprog_a) %>% 
  mutate(trans_todeath = trans_todeath_a) %>% 
  mutate(trans_fromprogtodeath = trans_fromprogtodeath_a) 
# first half a year sort

df %>% select(trans_toprog,trans_todeath,trans_fromprogtodeath,whereat_t1,whereat_t2,trans_remaininprog)

df <- df %>% 
  # 1 is pf, 2 is pp, 3 is death
  # nas to deal with      # start in alive conditions
  mutate(whereat_t2 = if_else( whereat_t1 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) <= timeinterval , 3 ,
                      if_else( whereat_t1 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) > timeinterval, 2 ,
                      if_else( whereat_t1 == 1 & trans_toprog > trans_todeath & trans_todeath <= timeinterval , 3 ,
                      if_else( whereat_t1 == 1 & trans_toprog > trans_todeath & trans_todeath > timeinterval , 1 ,
                      if_else( whereat_t1 == 1 & trans_todeath > timeinterval & trans_toprog > timeinterval , 1 , 
                      # start in prog conditions
                      if_else( whereat_t1 == 2 & trans_fromprogtodeath <= timeinterval , 3 ,
                      if_else( whereat_t1 == 2 & trans_fromprogtodeath > timeinterval , 2 , 0
                      )))))) )) %>% 
  # finalise dead, prog state for those reach it at this time point
  mutate(dead_s = if_else( whereat_t2 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , 1 ,
                           if_else( whereat_t2 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t1 == 2 & whereat_t2 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , dead_s 
                           )))) %>% 
  mutate(dead_t = if_else( whereat_t2 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , trans_todeath ,
                           if_else( whereat_t2 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F , (trans_toprog + trans_fromprogtodeath) , 
                           if_else( whereat_t1 == 2 & whereat_t2 == 3 & trans_fromprogtodeath < timeinterval  & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_fromprogtodeath  , dead_t 
                           )))) %>%                                                                        # changes on time period
  
  mutate(prog_s = if_else( whereat_t2 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 ,
                           if_else( whereat_t2 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t1 == 2 & whereat_t2 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , prog_s 
                           )))) %>% 
  mutate(prog_t = if_else( whereat_t2 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, trans_toprog ,
                           if_else( whereat_t2 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, (trans_toprog ) , prog_t
                           #if_else( whereat_t1 == 2 & whereat_t2 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_toprog , prog_t #problem
                           ))) %>% 
  # remaining prog time
  mutate(trans_remaininprog = if_else( whereat_t1 == 2 & whereat_t2 == 2 ,  trans_fromprogtodeath - timeinterval , 
                              if_else( whereat_t1 == 1 & whereat_t2 == 2 , trans_toprog + trans_fromprogtodeath - timeinterval , trans_remaininprog
                              )))

remainingprogtimearray <- df$trans_remaininprog


# tp3 -------------------------------------------------------------------------


trans_toprog_a <- rep(NA,1,n)
trans_todeath_a <- rep(NA,1,n)
trans_fromprogtodeath_a <- df$trans_fromprogtodeath
for(i in 1:n){
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[2])) ) == 2 & remainingprogtimearray[i] <= timeinterval ){
    trans_fromprogtodeath_a[i] <- remainingprogtimearray[i]
  } # zzz - with this array updated can update data
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[2])) ) == 2 & remainingprogtimearray[i] > timeinterval ){
    trans_fromprogtodeath_a[i] <- df$trans_fromprogtodeath[i] - timeinterval  
  } # zzz - with this array updated can update data
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[2])) ) ==1 ){
    
    trans_toprog_a[i] <- rweibull(n = 1, scale = exp(0.1+
                                                       0.01*age[i]+
                                                       0.4*t_2[i]+
                                                       0.1*v_2[i]),
                                  shape = 1/exp(0.1))
    trans_todeath_a[i] <- rweibull(n = 1, scale = exp(0.1+
                                                         -0.001*age[i]+
                                                         0.5*male[i]+
                                                        0.1*v_2[i]),
                                   shape = 1/exp(0.2))

  }# end if 

  
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[2])) ) == 3 ){
    trans_todeath_a[i] <- NA_real_
    trans_toprog_a[i] <- NA_real_
  }
}


df <- df %>% 
  mutate(trans_toprog = trans_toprog_a) %>% 
  mutate(trans_todeath = trans_todeath_a) %>% 
  mutate(trans_fromprogtodeath = trans_fromprogtodeath_a) 
# first half a year sort

df %>% select(trans_toprog,trans_todeath,trans_fromprogtodeath,whereat_t1,whereat_t2,trans_remaininprog)

df <- df %>% 
  # 1 is pf, 2 is pp, 3 is death
  # nas to deal with      # start in alive conditions
  mutate(whereat_t3 = if_else( whereat_t2 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) <= timeinterval , 3 ,
                      if_else( whereat_t2 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) > timeinterval, 2 ,
                      if_else( whereat_t2 == 1 & trans_toprog > trans_todeath & trans_todeath <= timeinterval , 3 ,
                      if_else( whereat_t2 == 1 & trans_toprog > trans_todeath & trans_todeath > timeinterval , 1 ,
                      if_else( whereat_t2 == 1 & trans_todeath > timeinterval & trans_toprog > timeinterval , 1 , 
                      # start in prog conditions
                      if_else( whereat_t2 == 2 & trans_fromprogtodeath <= timeinterval , 3 ,
                      if_else( whereat_t2 == 2 & trans_fromprogtodeath > timeinterval , 2 , 0
                      )))))) )) %>% 
  # finalise dead, prog state for those reach it at this time point
  mutate(dead_s = if_else( whereat_t3 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , 1 ,
                           if_else( whereat_t3 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t2 == 2 & whereat_t3 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , dead_s 
                           )))) %>% 
  mutate(dead_t = if_else( whereat_t3 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , trans_todeath ,
                           if_else( whereat_t3 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F , (trans_toprog + trans_fromprogtodeath) , 
                           if_else( whereat_t2 == 2 & whereat_t3 == 3 & trans_fromprogtodeath < timeinterval  & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_fromprogtodeath  , dead_t 
                           )))) %>%                                                                        # changes on time period
  
  mutate(prog_s = if_else( whereat_t3 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 ,
                           if_else( whereat_t3 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t2 == 2 & whereat_t3 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , prog_s 
                           )))) %>% 
  mutate(prog_t = if_else( whereat_t3 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, trans_toprog ,
                           if_else( whereat_t3 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, (trans_toprog ) , prog_t
                           #if_else( whereat_t1 == 2 & whereat_t2 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_toprog , prog_t #problem
                           ))) %>% 
  # remaining prog time
  mutate(trans_remaininprog = if_else( whereat_t2 == 2 & whereat_t3 == 2 ,  trans_fromprogtodeath - timeinterval , 
                              if_else( whereat_t2 == 1 & whereat_t3 == 2 , trans_toprog + trans_fromprogtodeath - timeinterval , trans_remaininprog
                                       )))
#  split those who carry on from prog and those who new to prog  

remainingprogtimearray <- df$trans_remaininprog



# tp4 -------------------------------------------------------------------------


trans_toprog_a <- rep(NA,1,n)
trans_todeath_a <- rep(NA,1,n)
trans_fromprogtodeath_a <- df$trans_fromprogtodeath
for(i in 1:n){
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[3])) ) == 2 & remainingprogtimearray[i] <= timeinterval ){
    trans_fromprogtodeath_a[i] <- remainingprogtimearray[i]
  } # zzz - with this array updated can update data
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[3])) ) == 2 & remainingprogtimearray[i] > timeinterval ){
    trans_fromprogtodeath_a[i] <- df$trans_fromprogtodeath[i] - timeinterval  
  } # zzz - with this array updated can update data
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[3])) ) ==1 ){
    
    trans_toprog_a[i] <- rweibull(n = 1, scale = exp(0.1+
                                                       0.01*age[i]+
                                                       0.4*t_3[i]+
                                                       0.1*v_3[i]),
                                  shape = 1/exp(0.1))
    trans_todeath_a[i] <- rweibull(n = 1, scale = exp(0.1+
                                                         -0.001*age[i]+
                                                         0.5*male[i]+
                                                        0.1*v_3[i]),
                                   shape = 1/exp(0.2))

  }# end if 

  
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[3])) ) == 3 ){
    trans_todeath_a[i] <- NA_real_
    trans_toprog_a[i] <- NA_real_
  }
}


df <- df %>% 
  mutate(trans_toprog = trans_toprog_a) %>% 
  mutate(trans_todeath = trans_todeath_a) %>% 
  mutate(trans_fromprogtodeath = trans_fromprogtodeath_a) 
# first half a year sort


df <- df %>% 
  # 1 is pf, 2 is pp, 3 is death
  # nas to deal with      # start in alive conditions
  mutate(whereat_t4 = if_else( whereat_t3 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) <= timeinterval , 3 ,
                      if_else( whereat_t3 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) > timeinterval, 2 ,
                      if_else( whereat_t3 == 1 & trans_toprog > trans_todeath & trans_todeath <= timeinterval , 3 ,
                      if_else( whereat_t3 == 1 & trans_toprog > trans_todeath & trans_todeath > timeinterval , 1 ,
                      if_else( whereat_t3 == 1 & trans_todeath > timeinterval & trans_toprog > timeinterval , 1 , 
                      # start in prog conditions
                      if_else( whereat_t3 == 2 & trans_fromprogtodeath <= timeinterval , 3 ,
                      if_else( whereat_t3 == 2 & trans_fromprogtodeath > timeinterval , 2 , 0
                      )))))) )) %>% 
  # finalise dead, prog state for those reach it at this time point
  mutate(dead_s = if_else( whereat_t4 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , 1 ,
                           if_else( whereat_t4 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t3 == 2 & whereat_t4 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , dead_s 
                           )))) %>% 
  mutate(dead_t = if_else( whereat_t4 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , trans_todeath ,
                           if_else( whereat_t4 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F , (trans_toprog + trans_fromprogtodeath) , 
                           if_else( whereat_t3 == 2 & whereat_t4 == 3 & trans_fromprogtodeath < timeinterval  & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_fromprogtodeath  , dead_t 
                           )))) %>%                                                                        # changes on time period
  
  mutate(prog_s = if_else( whereat_t4 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 ,
                           if_else( whereat_t4 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t3 == 2 & whereat_t4 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , prog_s 
                           )))) %>% 
  mutate(prog_t = if_else( whereat_t4 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, trans_toprog ,
                           if_else( whereat_t4 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, (trans_toprog ) , prog_t
                           #if_else( whereat_t1 == 2 & whereat_t2 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_toprog , prog_t #problem
                           ))) %>% 
  # remaining prog time
  mutate(trans_remaininprog = if_else( whereat_t3 == 2 & whereat_t4 == 2 ,  trans_fromprogtodeath - timeinterval , 
                              if_else( whereat_t3 == 1 & whereat_t4 == 2 , trans_toprog + trans_fromprogtodeath - timeinterval , trans_remaininprog
                                       )))

remainingprogtimearray <- df$trans_remaininprog


# tp5 -------------------------------------------------------------------------


trans_toprog_a <- rep(NA,1,n)
trans_todeath_a <- rep(NA,1,n)
trans_fromprogtodeath_a <- df$trans_fromprogtodeath
for(i in 1:n){
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[4])) ) == 2 & remainingprogtimearray[i] <= timeinterval ){
    trans_fromprogtodeath_a[i] <- remainingprogtimearray[i]
  } # zzz - with this array updated can update data
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[4])) ) == 2 & remainingprogtimearray[i] > timeinterval ){
    trans_fromprogtodeath_a[i] <- df$trans_fromprogtodeath[i] - timeinterval  
  } # zzz - with this array updated can update data
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[4])) ) ==1 ){
    
    trans_toprog_a[i] <- rweibull(n = 1, scale = exp(0.1+
                                                       0.01*age[i]+
                                                       0.4*t_4[i]+
                                                       0.1*v_4[i]),
                                  shape = 1/exp(0.1))
    trans_todeath_a[i] <- rweibull(n = 1, scale = exp(0.1+
                                                         -0.001*age[i]+
                                                         0.5*male[i]+
                                                        0.1*v_4[i]),
                                   shape = 1/exp(0.2))
 
  }# end if 

  
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[4])) ) == 3 ){
    trans_todeath_a[i] <- NA_real_
    trans_toprog_a[i] <- NA_real_
  }
}


df <- df %>% 
  mutate(trans_toprog = trans_toprog_a) %>% 
  mutate(trans_todeath = trans_todeath_a) %>% 
  mutate(trans_fromprogtodeath = trans_fromprogtodeath_a) 
# first half a year sort


df <- df %>% 
  # 1 is pf, 2 is pp, 3 is death
  # nas to deal with      # start in alive conditions
  mutate(whereat_t5 = if_else( whereat_t4 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) <= timeinterval , 3 ,
                      if_else( whereat_t4 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) > timeinterval, 2 ,
                      if_else( whereat_t4 == 1 & trans_toprog > trans_todeath & trans_todeath <= timeinterval , 3 ,
                      if_else( whereat_t4 == 1 & trans_toprog > trans_todeath & trans_todeath > timeinterval , 1 ,
                      if_else( whereat_t4 == 1 & trans_todeath > timeinterval & trans_toprog > timeinterval , 1 , 
                      # start in prog conditions
                      if_else( whereat_t4 == 2 & trans_fromprogtodeath <= timeinterval , 3 ,
                      if_else( whereat_t4 == 2 & trans_fromprogtodeath > timeinterval , 2 , 0
                      )))))) )) %>% 
  # finalise dead, prog state for those reach it at this time point
  mutate(dead_s = if_else( whereat_t5 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , 1 ,
                           if_else( whereat_t5 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t4 == 2 & whereat_t5 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , dead_s 
                           )))) %>% 
  mutate(dead_t = if_else( whereat_t5 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , trans_todeath ,
                           if_else( whereat_t5 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F , (trans_toprog + trans_fromprogtodeath) , 
                           if_else( whereat_t4 == 2 & whereat_t5 == 3 & trans_fromprogtodeath < timeinterval  & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_fromprogtodeath  , dead_t 
                           )))) %>%                                                                        # changes on time period
  
  mutate(prog_s = if_else( whereat_t5 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 ,
                           if_else( whereat_t5 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t4 == 2 & whereat_t5 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , prog_s 
                           )))) %>% 
  mutate(prog_t = if_else( whereat_t5 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, trans_toprog ,
                           if_else( whereat_t5 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, (trans_toprog ) , prog_t
                           #if_else( whereat_t1 == 2 & whereat_t2 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_toprog , prog_t #problem
                           ))) %>% 
  # remaining prog time
  mutate(trans_remaininprog = if_else( whereat_t4 == 2 & whereat_t5 == 2 ,  trans_fromprogtodeath - timeinterval , 
                              if_else( whereat_t4 == 1 & whereat_t5 == 2 , trans_toprog + trans_fromprogtodeath - timeinterval , trans_remaininprog
                                       )))

remainingprogtimearray <- df$trans_remaininprog


df %>% select(trans_toprog,trans_todeath,trans_fromprogtodeath,whereat_t3,whereat_t4,trans_remaininprog,dead_s,dead_t,prog_s,prog_t) 
df %>% select(trans_toprog,trans_todeath,trans_fromprogtodeath,whereat_t3,whereat_t4,trans_remaininprog,dead_s,dead_t,prog_s,prog_t) %>% 
  filter(whereat_t3==2 & whereat_t4 == 2)


# tp6 -------------------------------------------------------------------------


trans_toprog_a <- rep(NA,1,n)
trans_todeath_a <- rep(NA,1,n)
trans_fromprogtodeath_a <- df$trans_fromprogtodeath
for(i in 1:n){
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[5])) ) == 2 & remainingprogtimearray[i] <= timeinterval ){
    trans_fromprogtodeath_a[i] <- remainingprogtimearray[i]
  } # zzz - with this array updated can update data
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[5])) ) == 2 & remainingprogtimearray[i] > timeinterval ){
    trans_fromprogtodeath_a[i] <- df$trans_fromprogtodeath[i] - timeinterval  
  } # zzz - with this array updated can update data
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[5])) ) ==1 ){
    
    trans_toprog_a[i] <- rweibull(n = 1, scale = exp(0.1+ # 0.3
                                                       0.01*age[i]+
                                                       0.4*t_5[i]+
                                                       0.1*v_5[i]),
                                  shape = 1/exp(0.1)) #0.3
    trans_todeath_a[i] <- rweibull(n = 1, scale = exp(0.1+
                                                         -0.001*age[i]+
                                                         0.5*male[i]+
                                                        0.1*v_5[i]),
                                   shape = 1/exp(0.2)) #0.4
   
  }# end if 

  
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[5])) ) == 3 ){
    trans_todeath_a[i] <- NA_real_
    trans_toprog_a[i] <- NA_real_
  }
}


df <- df %>% 
  mutate(trans_toprog = trans_toprog_a) %>% 
  mutate(trans_todeath = trans_todeath_a) %>% 
  mutate(trans_fromprogtodeath = trans_fromprogtodeath_a) 
# first half a year sort


df <- df %>% 
  # 1 is pf, 2 is pp, 3 is death
  # nas to deal with      # start in alive conditions
  mutate(whereat_t6 = if_else( whereat_t5 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) <= timeinterval , 3 ,
                      if_else( whereat_t5 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) > timeinterval, 2 ,
                      if_else( whereat_t5 == 1 & trans_toprog > trans_todeath & trans_todeath <= timeinterval , 3 ,
                      if_else( whereat_t5 == 1 & trans_toprog > trans_todeath & trans_todeath > timeinterval , 1 ,
                      if_else( whereat_t5 == 1 & trans_todeath > timeinterval & trans_toprog > timeinterval , 1 , 
                      # start in prog conditions
                      if_else( whereat_t5 == 2 & trans_fromprogtodeath <= timeinterval , 3 ,
                      if_else( whereat_t5 == 2 & trans_fromprogtodeath > timeinterval , 2 , 0
                      )))))) )) %>% 
  # finalise dead, prog state for those reach it at this time point
  mutate(dead_s = if_else( whereat_t6 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , 1 ,
                           if_else( whereat_t6 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t5 == 2 & whereat_t6 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , dead_s 
                           )))) %>% 
  mutate(dead_t = if_else( whereat_t6 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , trans_todeath ,
                           if_else( whereat_t6 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F , (trans_toprog + trans_fromprogtodeath) , 
                           if_else( whereat_t5 == 2 & whereat_t6 == 3 & trans_fromprogtodeath < timeinterval  & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_fromprogtodeath  , dead_t 
                           )))) %>%                                                                        # changes on time period
  
  mutate(prog_s = if_else( whereat_t6 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 ,
                           if_else( whereat_t6 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t5 == 2 & whereat_t6 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , prog_s 
                           )))) %>% 
  mutate(prog_t = if_else( whereat_t6 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, trans_toprog ,
                           if_else( whereat_t6 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, (trans_toprog ) , prog_t
                           #if_else( whereat_t1 == 2 & whereat_t2 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_toprog , prog_t #problem
                           ))) %>% 
  # remaining prog time
  mutate(trans_remaininprog = if_else( whereat_t5 == 2 & whereat_t6 == 2 ,  trans_fromprogtodeath - timeinterval , 
                              if_else( whereat_t5 == 1 & whereat_t6 == 2 , trans_toprog + trans_fromprogtodeath - timeinterval , trans_remaininprog
                                       )))

remainingprogtimearray <- df$trans_remaininprog



# tp7 -------------------------------------------------------------------------


trans_toprog_a <- rep(NA,1,n)
trans_todeath_a <- rep(NA,1,n)
trans_fromprogtodeath_a <- df$trans_fromprogtodeath
for(i in 1:n){
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[6])) ) == 2 & remainingprogtimearray[i] <= timeinterval ){
    trans_fromprogtodeath_a[i] <- remainingprogtimearray[i]
  } # zzz - with this array updated can update data
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[6])) ) == 2 & remainingprogtimearray[i] > timeinterval ){
    trans_fromprogtodeath_a[i] <- df$trans_fromprogtodeath[i] - timeinterval  
  } # zzz - with this array updated can update data
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[6])) ) ==1 ){
    
    trans_toprog_a[i] <- rweibull(n = 1, scale = exp(0.1+
                                                       0.01*age[i]+
                                                       0.4*t_6[i]+
                                                       0.1*v_6[i]),
                                  shape = 1/exp(0.1))
    trans_todeath_a[i] <- rweibull(n = 1, scale = exp(0.1+
                                                         -0.001*age[i]+
                                                         0.5*male[i]+
                                                        0.1*v_6[i]),
                                   shape = 1/exp(0.2))
  
  }# end if 

  
  if(df %>% filter(id==i) %>% pull( eval(parse(text=where_array[6])) ) == 3 ){
    trans_todeath_a[i] <- NA_real_
    trans_toprog_a[i] <- NA_real_
  }
}


df <- df %>% 
  mutate(trans_toprog = trans_toprog_a) %>% 
  mutate(trans_todeath = trans_todeath_a) %>% 
  mutate(trans_fromprogtodeath = trans_fromprogtodeath_a) 
# first half a year sort


df <- df %>% 
  # 1 is pf, 2 is pp, 3 is death
  # nas to deal with      # start in alive conditions
  mutate(whereat_t7 = if_else( whereat_t6 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) <= timeinterval , 3 ,
                      if_else( whereat_t6 == 1 & trans_toprog < trans_todeath & trans_toprog < timeinterval & (trans_toprog + trans_fromprogtodeath) > timeinterval, 2 ,
                      if_else( whereat_t6 == 1 & trans_toprog > trans_todeath & trans_todeath <= timeinterval , 3 ,
                      if_else( whereat_t6 == 1 & trans_toprog > trans_todeath & trans_todeath > timeinterval , 1 ,
                      if_else( whereat_t6 == 1 & trans_todeath > timeinterval & trans_toprog > timeinterval , 1 , 
                      # start in prog conditions
                      if_else( whereat_t6 == 2 & trans_fromprogtodeath <= timeinterval , 3 ,
                      if_else( whereat_t6 == 2 & trans_fromprogtodeath > timeinterval , 2 , 0
                      )))))) )) %>% 
  # finalise dead, prog state for those reach it at this time point
  mutate(dead_s = if_else( whereat_t7 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , 1 ,
                           if_else( whereat_t7 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t6 == 2 & whereat_t7 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , dead_s 
                           )))) %>% 
  mutate(dead_t = if_else( whereat_t7 == 3 & trans_todeath < trans_toprog & is.na(trans_toprog)==F & is.na(trans_todeath)==F , trans_todeath ,
                           if_else( whereat_t7 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval & is.na(trans_toprog)==F & is.na(trans_todeath)==F , (trans_toprog + trans_fromprogtodeath) , 
                           if_else( whereat_t6 == 2 & whereat_t7 == 3 & trans_fromprogtodeath < timeinterval  & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_fromprogtodeath  , dead_t 
                           )))) %>%                                                                        # changes on time period
  
  mutate(prog_s = if_else( whereat_t7 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 ,
                           if_else( whereat_t7 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, 1 , 
                           if_else( whereat_t6 == 2 & whereat_t7 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , 1 , prog_s 
                           )))) %>% 
  mutate(prog_t = if_else( whereat_t7 == 2 & trans_toprog < trans_todeath & trans_toprog < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, trans_toprog ,
                           if_else( whereat_t7 == 3 & trans_toprog < trans_todeath & (trans_toprog + trans_fromprogtodeath) < timeinterval  & is.na(trans_toprog)==F & is.na(trans_todeath)==F, (trans_toprog ) , prog_t
                           #if_else( whereat_t1 == 2 & whereat_t2 == 3 & trans_fromprogtodeath < timeinterval & is.na(trans_toprog)==T & is.na(trans_todeath)==T , trans_toprog , prog_t #problem
                           ))) %>% 
  # remaining prog time
  mutate(trans_remaininprog = if_else( whereat_t6 == 2 & whereat_t7 == 2 ,  trans_fromprogtodeath - timeinterval , 
                              if_else( whereat_t6 == 1 & whereat_t7 == 2 , trans_toprog + trans_fromprogtodeath - timeinterval , trans_remaininprog
                                       )))

remainingprogtimearray <- df$trans_remaininprog


prop.table(table(is.na(df$dead_t)))
df %>% select(where_array,trans_remaininprog,dead_s,dead_t,prog_s,prog_t) %>% 
  filter(trans_remaininprog<0)



# tidy data ---------------------------------------------------------------

df %>% select(where_array,trans_remaininprog,dead_s,dead_t,prog_s,prog_t)

# dead and prog are relative to where cols

df %>% select(where_array,trans_remaininprog,dead_s,dead_t,prog_s,prog_t) %>% 
  filter(whereat_t2 == 3 & whereat_t1 == 1) # in this cases dead is sum of dead and prog


df <- df %>% 
  # time 0
  mutate(real_prog_t =  if_else(whereat_t2 == 3 & whereat_t1 == 1 & prog_s == 1, 1*timeinterval + prog_t ,  
                        if_else(whereat_t2 == 2 & whereat_t1 == 1 , 1*timeinterval + prog_t  , #zzz come back and check?
                        if_else(whereat_t1 == 3 &  prog_s == 1 , prog_t , 
                        if_else(whereat_t1 == 2  , prog_t + 0*timeinterval , NA_real_ 
                               ))))) %>% 
  mutate(real_dead_t = if_else(whereat_t1 == 3 & prog_s == 1 , prog_t + dead_t , 
                       if_else(whereat_t1 == 3 & prog_s == 0 , dead_t + 0*timeinterval  , 
                       if_else(whereat_t1 == 2 , 1*timeinterval + dead_t , 
                       if_else(whereat_t2 == 3 & whereat_t1 == 1 , 1*timeinterval + dead_t , NA_real_ 
                               ))))) %>% 
  # time 1
  mutate(real_prog_t = if_else(whereat_t3 == 3 & whereat_t2 == 1 & prog_s == 1, 2*timeinterval + prog_t ,  
                       if_else(whereat_t3 == 2 & whereat_t2 == 1 , 2*timeinterval + prog_t ,  
                       if_else(whereat_t2 == 1  ,2*timeinterval + prog_t, real_prog_t , real_prog_t )))) %>%  
  mutate(real_dead_t = if_else(whereat_t3 == 3 & whereat_t2 == 1 , 2*timeinterval + dead_t  , 
                       if_else(whereat_t2 == 2 , 2*timeinterval + dead_t, real_dead_t,  real_dead_t ))) %>% 
  # time 2
  mutate(real_prog_t = if_else(whereat_t4 == 3 & whereat_t3 == 1 & prog_s == 1, 3*timeinterval + prog_t ,  
                       if_else(whereat_t4 == 2 & whereat_t3 == 1 , 3*timeinterval + prog_t ,  
                       if_else(whereat_t3 == 1,  3*timeinterval + prog_t , real_prog_t, real_prog_t )))) %>%  
  mutate(real_dead_t = if_else(whereat_t4 == 3 & whereat_t3 == 1 , 3*timeinterval + dead_t , 
                       if_else(whereat_t3 == 2 , 3*timeinterval + dead_t , real_dead_t , real_dead_t))) %>% 
  # time 3
  mutate(real_prog_t = if_else(whereat_t5 == 3 & whereat_t4 == 1 & prog_s == 1, 4*timeinterval + prog_t , 
                       if_else(whereat_t5 == 2 & whereat_t4 == 1 , 4*timeinterval + prog_t ,  
                       if_else(whereat_t4 == 1 , 4*timeinterval + prog_t , real_prog_t , real_prog_t )))) %>%  
  mutate(real_dead_t = if_else(whereat_t5 == 3 & whereat_t4 == 1 , 4*timeinterval + dead_t ,  
                       if_else(whereat_t4 == 2 , 4*timeinterval + dead_t , real_dead_t,  real_dead_t))) %>% 
  # time 4
  mutate(real_prog_t = if_else(whereat_t6 == 3 & whereat_t5 == 1 & prog_s == 1, 5*timeinterval + prog_t , 
                       if_else(whereat_t6 == 2 & whereat_t5 == 1 , 5*timeinterval + prog_t ,  
                       if_else(whereat_t5 == 1 , 5*timeinterval + prog_t , real_prog_t, real_prog_t )))) %>%  
  mutate(real_dead_t = if_else(whereat_t6 == 3 & whereat_t5 == 1 , 5*timeinterval + dead_t , 
                       if_else(whereat_t5 == 2 , 5*timeinterval + dead_t , real_dead_t , 
                        real_dead_t))) %>% 
  # time 5
  mutate(real_prog_t = if_else(whereat_t7 == 3 & whereat_t6 == 1 & prog_s == 1, 6*timeinterval + prog_t , 
                       if_else(whereat_t7 == 2 & whereat_t6 == 1 , 6*timeinterval + prog_t ,  
                       if_else(whereat_t6 == 1 , 6*timeinterval + prog_t , real_prog_t , real_prog_t)))) %>%  
  mutate(real_dead_t = if_else(whereat_t7 == 3 & whereat_t6 == 1 , 6*timeinterval + dead_t ,  
                       if_else(whereat_t6 == 2 , 6*timeinterval + dead_t , real_dead_t , 
                       real_dead_t))) %>% 
  # time 6
  mutate(real_prog_t = if_else(whereat_t7 == 1 , 7*timeinterval + prog_t , real_prog_t, real_prog_t )) %>%  
  mutate(real_dead_t = if_else(whereat_t7 == 2 , 7*timeinterval + dead_t , real_dead_t , real_dead_t )) %>% 
  # time 7
  # NA time if did not dead/prog
  mutate(real_prog_t =  if_else( is.na(real_prog_t)==T & prog_s==0 & dead_s==0, fup_array[timepoints] , 
                        if_else( is.na(real_prog_t)==T & prog_s==0 & dead_s==1 , real_dead_t , real_prog_t))) %>% 
  mutate(real_dead_t =  if_else( is.na(real_dead_t)==T & dead_s==0 & prog_s==0 , fup_array[timepoints] , 
                        if_else( is.na(real_dead_t)==T & dead_s==0 & prog_s==1 , fup_array[timepoints] ,real_dead_t))) 
df %>% select(where_array,dead_s,dead_t,prog_s,prog_t,real_dead_t,real_prog_t)





