# inspect covariates ---------------------------------------------------------------


summary(df) 
head(surv_long2)


baseline_values_conf <- surv_long2 %>%
  select(id,age,male, t_, v_) %>% 
  group_by(t_) %>%
  summarise(avg_age_grp = mean(age), avg_male_grp = mean(male))

print(baseline_values_conf)

baseline_covariates_conf <- surv_long2 %>%
  filter(vst==0) %>% 
  select(id,vst, age, male, v_, t_) %>%
  unique()
patient_covariates_conf <- surv_long2 %>%
  select(id,vst, age, male, v_, t_) %>%
  unique()

# baseline
plt <- ggplot(baseline_covariates_conf) +
  geom_density(aes(x = age, col = factor(t_),linetype=factor(t_)),linewidth=2) + 
  labs( 
    col = "treatment group", 
    x = "age") +
  theme(text = element_text(size=60))+
  scale_color_manual(values=c('black', 'azure4')) +
  theme(legend.position="none")
ggsave(plt,file=paste0("tva_age_density.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

plt <- ggplot(baseline_covariates_conf) +
  geom_density(aes(x = age),linewidth=2) + 
  labs(
    x = "age") + 
  theme(text = element_text(size=60))
ggsave(plt,file=paste0("tva_ageoverall_density.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

plt <- ggplot(baseline_covariates_conf) +
  geom_bar(aes(x = male, fill = factor(t_)),position = "fill") +
  labs(
    fill = "treatment group",
    x = "male",y="proportion of pop")+
  scale_fill_manual(values=c('black', 'azure4')) +
  theme(text = element_text(size=50))+
  theme(legend.position="none")
ggsave(plt,file=paste0("tva_male_density.png"), width =  1200, height = 210 , units = "mm", dpi = 300)
baseline_covariates_conf %>%
  select(id, t_, male) %>% 
  group_by(male) %>%
  summarise( prop_taketx_t0 = mean(t_))


# time varying
plt <- ggplot(patient_covariates_conf) + 
  geom_density(aes(x = v_, col = factor(t_),linetype=factor(t_)),linewidth=2) + 
  labs(
    col = "treatment group", 
    x = "time varying variable (v_)")+
  facet_wrap(~vst) +
  theme(text = element_text(size=60))+
  scale_color_manual(values=c('black', 'azure4')) +
  theme(legend.position="none")
ggsave(plt,file=paste0("tva_v_density.png"), width =  1200, height = 400 , units = "mm", dpi = 300)

baseline_covariates_conf %>%
     select(id, t_, male) %>%
     group_by(male) %>%
     summarise( prop_taketx_t0 = mean(t_))

# eq5d pf ----------------------------------------------------------------------

# hist of eq5d over time by tx grouo

mu <- plyr::ddply(surv_long2, "t_", summarise, grp.mean=mean(eq5d_pf_))


hist(surv_long2$eq5d_pf_)
plt <- ggplot(surv_long2, aes(x=eq5d_pf_, fill=factor(t_))) +
  geom_histogram(position="identity", alpha=0.5)+
  labs(#title = "density of age for overall population",
    x = "EQ5D", y= "Count") +
  scale_color_grey()+scale_fill_grey(name = "Tx Group") +
  theme_classic()+
  theme(text = element_text(size=50)) +
  facet_wrap(~vst)
  # geom_vline(data=mu, aes(xintercept=grp.mean, color=t_),
  #             linetype="dashed")
ggsave(plt,file=paste0("eq5d_hist_txgroup_vst.png"), width =  1200, height = 350 , units = "mm", dpi = 300)


# overall avg eq5d
avgpf_dat <- surv_long2 %>% 
  select(vst,eq5d_pf_) %>% 
  group_by(vst) %>%
  mutate(sumi= sum(eq5d_pf_)) %>% 
  mutate(n=n()) %>% 
  ungroup(vst) %>% 
  mutate(avg_eq5d_pf = sumi/n) %>% 
  distinct(vst,avg_eq5d_pf) %>% 
  mutate(sixmonth = if_else(vst==0 , 0 ,
                            if_else(vst==1 , 0.5,
                                    if_else(vst==2 , 1,
                                            if_else(vst==3 , 1.5,
                                                    if_else(vst==4 , 2,
                                                            if_else(vst==5 , 2.5,
                                                                    if_else(vst==6 , 3,
                                                                            if_else(vst==7 , 3.5,4
                                                                            )))))))) )

surv_edit <-  surv_long2 %>%   mutate(sixmonth = if_else(vst==0 , 0 ,
                                                         if_else(vst==1 , 0.5,
                                                                 if_else(vst==2 , 1,
                                                                         if_else(vst==3 , 1.5,
                                                                                 if_else(vst==4 , 2,
                                                                                         if_else(vst==5 , 2.5,
                                                                                                 if_else(vst==6 , 3,
                                                                                                         if_else(vst==7 , 3.5,4
                                                                                                         )))))))) )

plt <- ggplot()+
  #geom_point() +
  geom_line(data=surv_edit ,aes(x=sixmonth,y=eq5d_pf_,group=id) ,alpha=0.05,colour="darkgrey") +
  geom_line(aes(x=avgpf_dat$sixmonth, y=avgpf_dat$avg_eq5d_pf,group=1),colour="black") +
  labs(#title = "density of age for overall population",
    x = "Year", y= "EQ5D score") +
  theme(text = element_text(size=60))
ggsave(plt,file=paste0("datagen_overallEQ5Dtrend.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

# by treatment group
avgpf_dat <- surv_long2 %>% 
  select(vst,t_,eq5d_pf_) %>% 
  group_by(vst,t_) %>%
  mutate(sumi= sum(eq5d_pf_)) %>% 
  mutate(sdi= sd(eq5d_pf_)) %>% 
  mutate(n=n()) %>% 
  ungroup(vst,t_) %>% 
  mutate(avg_eq5d_pf = sumi/n) %>% 
  distinct(vst,t_,avg_eq5d_pf,sdi) %>% 
  mutate(sixmonth = if_else(vst==0 , 0 ,
                            if_else(vst==1 , 0.5,
                                    if_else(vst==2 , 1,
                                            if_else(vst==3 , 1.5,
                                                    if_else(vst==4 , 2,
                                                            if_else(vst==5 , 2.5,
                                                                    if_else(vst==6 , 3,
                                                                            if_else(vst==7 , 3.5,4
                                                                            )))))))) ) %>% 
  mutate(lci = avg_eq5d_pf - 1.96*(sdi/sqrt(n))) %>% 
  mutate(uci = avg_eq5d_pf + 1.96*(sdi/sqrt(n))) 

avgpf_dat$t_ <- as.factor(avgpf_dat$t_)
plt <- ggplot(data=avgpf_dat)+
  #geom_point() +
  #geom_line(data=surv_long2 ,aes(x=vst,y=eq5d_pp_,group=id) ,alpha=0.05,colour="darkgrey") +
  geom_point(aes(x=vst, y=avg_eq5d_pf,color=t_,shape=t_),size=5) +
  #geom_errorbar(aes(x = vst,ymin=lci,ymax=uci,color=t_,shape=t_),size=2) +
  labs(#title = "density of age for overall population",
    x = "Year", y= "EQ5D score") + 
  scale_color_manual(values=c('black', 'azure4'))+
  theme(legend.position="none")+
  theme(text = element_text(size=60))

surv_long2 %>% select(vst,eq5d_pf_,t_)
ggplot(surv_long2, aes(x=factor(vst), y=eq5d_pf_,fill=t_)) + 
  geom_boxplot() +
  ylim(0,1)


ggsave(plt,file=paste0("datagen_txgroupEQ5Dtrend.png"), width =  1200, height = 210 , units = "mm", dpi = 300)


# by age
surv_long2["age_group"] = cut(surv_long2$age, c(0, 50, 60, 70,80,100), c("0-50", "50-60", "60-70", "70-80", "80-100"), include.lowest=TRUE)

# by treatment group
avgpf_dat <- surv_long2 %>% 
  select(vst,age_group,eq5d_pf_) %>% 
  group_by(vst,age_group) %>%
  mutate(sumi= sum(eq5d_pf_)) %>% 
  mutate(n=n()) %>% 
  ungroup(vst,age_group) %>% 
  mutate(avg_eq5d_pf = sumi/n) %>% 
  distinct(vst,age_group,avg_eq5d_pf) %>% 
  mutate(sixmonth = if_else(vst==0 , 0 ,
                            if_else(vst==1 , 0.5,
                                    if_else(vst==2 , 1,
                                            if_else(vst==3 , 1.5,
                                                    if_else(vst==4 , 2,
                                                            if_else(vst==5 , 2.5,
                                                                    if_else(vst==6 , 3,
                                                                            if_else(vst==7 , 3.5,4
                                                                            )))))))) )


avgpf_dat$age_group <- as.factor(avgpf_dat$age_group)
plt <- ggplot(data=avgpf_dat)+
  #geom_point() +
  #geom_line(data=surv_long2 ,aes(x=vst,y=eq5d_pp_,group=id) ,alpha=0.05,colour="darkgrey") +
  geom_point(aes(x=vst, y=avg_eq5d_pf,color=age_group,shape=age_group),size=6) +
  labs(#title = "density of age for overall population",
    x = "Year", y= "EQ5D score") + 
  scale_color_discrete(name = "Age group") +
  scale_shape_discrete(name = "Age group") +
  #scale_color_manual(values=c('black', 'azure4'))+
  #theme(legend.position="none")+
  theme(text = element_text(size=60))
ggsave(plt,file=paste0("datagen_agegrpEQ5Dtrend.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

surv_long2["age_group"] = cut(surv_long2$age, c(0, 60, 70,80,100), c("0-60", "60-70", "70-80", "80-100"), include.lowest=TRUE)

plt <- ggplot(surv_long2, aes(x=factor(age_group), y=eq5d_pf_,fill_t_)) + 
  geom_boxplot() +
  theme_classic()+
  theme(text = element_text(size=60)) +
  ylim(0,1)+
  labs(#title = "density of age for overall population",
    x = "Age group", y= "EQ5D") 
ggsave(plt,file=paste0("eq5d_byagegroup.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

# male not needed as did not generate eq5d
# by v_
surv_long2["v_group"] = cut(surv_long2$v_, c(5, 6, 7, 8,9,10,11,12), c("5-6", "6-7", "7-8", "8-9", "9-10","10-11","11-12"), include.lowest=TRUE)

avgpf_dat <- surv_long2 %>% 
  select(v_group,eq5d_pf_) %>% 
  group_by(v_group) %>%
  mutate(sumi= sum(eq5d_pf_)) %>% 
  mutate(sd = sd(eq5d_pf_)) %>% 
  mutate(n=n()) %>% 
  ungroup(v_group) %>% 
  mutate(avg_eq5d_pf = sumi/n) %>% 
  distinct(v_group,avg_eq5d_pf,sd) %>% 
  mutate(lci = avg_eq5d_pf - 1.96*(sd/sqrt(n))) %>% 
  mutate(uci = avg_eq5d_pf + 1.96*(sd/sqrt(n))) 
 
avgpf_dat$v_group <- as.factor(avgpf_dat$v_group)

plt <- ggplot()+
  geom_point(data=avgpf_dat,aes(x=v_group,y=avg_eq5d_pf),size=4) +
  geom_errorbar(data=avgpf_dat,aes(x = v_group,ymin=lci,ymax=uci),size=2) +
  labs(y="EQ5D",x="v group")+
  theme(text = element_text(size=50))
ggsave(plt,file=paste0("datagen_vgrpEQ5Dtrend.png"), width =  1200, height = 210 , units = "mm", dpi = 300)


ggplot(surv_long2, aes(x=eq5d_pf_)) +
  geom_histogram(position="identity", alpha=0.5)+
  labs(#title = "density of age for overall population",
    x = "EQ5D", y= "Count") +
  theme_classic()+
  theme(text = element_text(size=50)) +
  facet_wrap(~v_group)


plt <- ggplot(surv_long2, aes(x=factor(v_group), y=eq5d_pf_,fill_t_)) + 
  geom_boxplot() +
  theme_classic()+
  theme(text = element_text(size=60)) +
  ylim(0,1)+
  labs(#title = "density of age for overall population",
    x = "V group", y= "EQ5D") 
ggsave(plt,file=paste0("eq5d_byvgroup.png"), width =  1200, height = 210 , units = "mm", dpi = 300)


# eq5d pp ----------------------------------------------------------------------


plt <- ggplot(surv_long2, aes(x=eq5d_pp_, fill=factor(t_))) +
  geom_histogram(position="identity", alpha=0.5)+
  labs(#title = "density of age for overall population",
    x = "EQ5D", y= "Count") +
  scale_color_grey()+scale_fill_grey(name = "Tx Group") +
  theme_classic()+
  theme(text = element_text(size=50)) +
  facet_wrap(~vst)

ggsave(plt,file=paste0("eq5d_hist_txgroup_vst_pp.png"), width =  1200, height = 350 , units = "mm", dpi = 300)


# hist eq5d
plt <- ggplot(data=surv_long2)+
  geom_histogram(aes(x=eq5d_pf_)) +
  labs(x="EQ5D")+
  theme(text = element_text(size=60))+
  facet_wrap(~vst)
ggsave(plt,file=paste0("hist_geneq5ddist.png"), width =  1200, height = 290 , units = "mm", dpi = 300)
plt <- ggplot(data=surv_long2)+
  geom_histogram(aes(x=eq5d_pp_)) +
  labs(x="EQ5D")+
  theme(text = element_text(size=60))+
  facet_wrap(~vst)
ggsave(plt,file=paste0("hist_geneq5ddist_pp.png"), width =  1200, height = 290 , units = "mm", dpi = 300)


# overall avg eq5d
avgpf_dat <- surv_long2 %>% 
  select(vst,eq5d_pp_) %>% 
  group_by(vst) %>%
  mutate(sumi= sum(eq5d_pp_)) %>% 
  mutate(n=n()) %>% 
  ungroup(vst) %>% 
  mutate(avg_eq5d_pf = sumi/n) %>% 
  distinct(vst,avg_eq5d_pf) %>% 
  mutate(sixmonth = if_else(vst==0 , 0 ,
                            if_else(vst==1 , 0.5,
                                    if_else(vst==2 , 1,
                                            if_else(vst==3 , 1.5,
                                                    if_else(vst==4 , 2,
                                                            if_else(vst==5 , 2.5,
                                                                    if_else(vst==6 , 3,
                                                                            if_else(vst==7 , 3.5,4
                                                                            )))))))) )

surv_edit <-  surv_long2 %>%   mutate(sixmonth = if_else(vst==0 , 0 ,
                                                         if_else(vst==1 , 0.5,
                                                                 if_else(vst==2 , 1,
                                                                         if_else(vst==3 , 1.5,
                                                                                 if_else(vst==4 , 2,
                                                                                         if_else(vst==5 , 2.5,
                                                                                                 if_else(vst==6 , 3,
                                                                                                         if_else(vst==7 , 3.5,4
                                                                                                         )))))))) )

plt <- ggplot()+
  #geom_point() +
  geom_line(data=surv_edit ,aes(x=sixmonth,y=eq5d_pp_,group=id) ,alpha=0.15,colour="darkgrey") +
  geom_line(aes(x=avgpf_dat$sixmonth, y=avgpf_dat$avg_eq5d_pf,group=1),colour="black") +
  labs(#title = "density of age for overall population",
    x = "Year", y= "EQ5D score") +
  theme(text = element_text(size=60))

ggsave(plt,file=paste0("datagen_overallEQ5Dtrend_pp.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

# by treatment group
avgpf_dat <- surv_long2 %>% 
  select(vst,t_,eq5d_pp_) %>% 
  group_by(vst,t_) %>%
  mutate(sumi= sum(eq5d_pp_)) %>% 
  mutate(sdi= sum(eq5d_pp_)) %>% 
  mutate(n=n()) %>% 
  ungroup(vst,t_) %>% 
  mutate(avg_eq5d_pp = sumi/n) %>% 
  distinct(vst,t_,avg_eq5d_pp,sdi) %>% 
  mutate(sixmonth = if_else(vst==0 , 0 ,
                            if_else(vst==1 , 0.5,
                                    if_else(vst==2 , 1,
                                            if_else(vst==3 , 1.5,
                                                    if_else(vst==4 , 2,
                                                            if_else(vst==5 , 2.5,
                                                                    if_else(vst==6 , 3,
                                                                            if_else(vst==7 , 3.5,4
                                                                            )))))))) )%>% 
  mutate(lci = avg_eq5d_pp - 1.96*(sdi/sqrt(n))) %>% 
  mutate(uci = avg_eq5d_pp + 1.96*(sdi/sqrt(n))) 



avgpf_dat$t_ <- as.factor(avgpf_dat$t_)
plt <- ggplot(data=avgpf_dat)+
  geom_point(aes(x=vst, y=avg_eq5d_pp,color=t_,shape=t_),size=5) +
  labs(#title = "density of age for overall population",
    x = "Year", y= "EQ5D score") + 
  scale_color_manual(values=c('black', 'azure4'))+
  theme(legend.position="none")+
  theme(text = element_text(size=60))



ggsave(plt,file=paste0("datagen_txgroupEQ5Dtrend_pp.png"), width =  1200, height = 210 , units = "mm", dpi = 300)



# by age
surv_long2["age_group"] = cut(surv_long2$age, c(0, 50, 60, 70,80,100), c("0-50", "50-60", "60-70", "70-80", "80-100"), include.lowest=TRUE)

# by treatment group
avgpf_dat <- surv_long2 %>% 
  select(vst,age_group,eq5d_pp_) %>% 
  group_by(vst,age_group) %>%
  mutate(sumi= sum(eq5d_pp_)) %>% 
  mutate(n=n()) %>% 
  ungroup(vst,age_group) %>% 
  mutate(avg_eq5d_pf = sumi/n) %>% 
  distinct(vst,age_group,avg_eq5d_pf) %>% 
  mutate(sixmonth = if_else(vst==0 , 0 ,
                            if_else(vst==1 , 0.5,
                                    if_else(vst==2 , 1,
                                            if_else(vst==3 , 1.5,
                                                    if_else(vst==4 , 2,
                                                            if_else(vst==5 , 2.5,
                                                                    if_else(vst==6 , 3,
                                                                            if_else(vst==7 , 3.5,4
                                                                            )))))))) )



avgpf_dat$age_group <- as.factor(avgpf_dat$age_group)
plt <- ggplot(data=avgpf_dat)+
  geom_point(aes(x=vst, y=avg_eq5d_pf,color=age_group,shape=age_group),size=3) +
  labs(#title = "density of age for overall population",
    x = "Year", y= "EQ5D score") + 
  scale_color_discrete(name = "Age group") +
  scale_shape_discrete(name = "Age group") +
  theme(text = element_text(size=60))
ggsave(plt,file=paste0("datagen_agegrpEQ5Dtrend_pp.png"), width =  1200, height = 210 , units = "mm", dpi = 300)


# male not needed as did not generate eq5d
# by v_
surv_long2["v_group"] = cut(surv_long2$v_, c(5, 6, 7, 8,9,10,11,12), c("5-6", "6-7", "7-8", "8-9", "9-10","10-11","11-12"), include.lowest=TRUE)

avgpf_dat <- surv_long2 %>% 
  select(v_group,eq5d_pp_) %>% 
  group_by(v_group) %>%
  mutate(sumi= sum(eq5d_pp_)) %>% 
  mutate(sd = sd(eq5d_pp_)) %>% 
  mutate(n=n()) %>% 
  ungroup(v_group) %>% 
  mutate(avg_eq5d_pf = sumi/n) %>% 
  distinct(v_group,avg_eq5d_pf,sd) %>% 
  mutate(lci = avg_eq5d_pf - 1.96*(sd/sqrt(n))) %>% 
  mutate(uci = avg_eq5d_pf + 1.96*(sd/sqrt(n))) 

avgpf_dat$v_group <- as.factor(avgpf_dat$v_group)

plt <- ggplot()+
  geom_point(data=avgpf_dat,aes(x=v_group,y=avg_eq5d_pf),size=4) +
  geom_errorbar(data=avgpf_dat,aes(x = v_group,ymin=lci,ymax=uci),size=2) +
  labs(y="EQ5D",x="v group")+
  theme(text = element_text(size=50))
ggsave(plt,file=paste0("datagen_vgrpEQ5Dtrend_pp.png"), width =  1200, height = 210 , units = "mm", dpi = 300)


# inspect cost pf ------------------------------------------------------------

# hist of costperday
pltdat <- surv_long2 %>% filter(vst==0) %>% select(id,vst,t_,cost.pf,cost.pp)

plt <- ggplot(data=pltdat)+
  geom_histogram(aes(x=cost.pf)) +
  labs(x="cost per day")+
  theme(text = element_text(size=60))
ggsave(plt,file=paste0("hist_gencost.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

plt <- ggplot(data=pltdat)+
  geom_histogram(aes(x=cost.pp)) +
  labs(x="cost per day")+
  theme(text = element_text(size=60))
ggsave(plt,file=paste0("hist_gencost_pp.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

plt <- ggplot(data=pltdat)+
  geom_histogram(aes(x=cost.pp,fill=t_)) +
  labs(x="cost per day")+
  theme(text = element_text(size=60))
ggsave(plt,file=paste0("hist_gencost_pp.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

# box plot
plt <- ggplot(surv_long2, aes(x=factor(age_group), y=eq5d_pf_,fill_t_)) + 
  geom_boxplot() +
  theme_classic()+
  theme(text = element_text(size=60)) +
  ylim(0,1)+
  labs(#title = "density of age for overall population",
    x = "Age group", y= "EQ5D") 
ggsave(plt,file=paste0("eq5d_byagegroup.png"), width =  1200, height = 210 , units = "mm", dpi = 300)


surv_long2 %>% filter(vst==0) %>% select(id,vst,costin_pf,costin_pp) 

summary(surv_long2 %>% filter(vst==0) %>% select(id,vst,costin_pf,costin_pp) %>% pull(costin_pf) )
summary(surv_long2 %>% filter(vst==0 & t_==0) %>% select(id,vst,costin_pf,costin_pp) %>% pull(costin_pf) )


# age vs costs
surv_long2 %>% filter(vst==0) %>% select(id,vst,age,costin_pf,costin_pp)

plt <- ggplot(data=surv_long2 %>% filter(vst==0))+
  geom_point(aes(x=age,y=costin_pf),alpha=0.35) +
  labs(y="Total Cost",x="Age")+
  theme(text = element_text(size=60))
ggsave(plt,file=paste0("inspect_agecost.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

surv_long2["age_group"] = cut(surv_long2$age, c(0, 50, 60, 70,80,100), c("0-50", "50-60", "60-70", "70-80", "80-100"), include.lowest=TRUE)
pltdat <- surv_long2 %>% group_by(age_group) %>% 
  filter(vst==0) %>% 
  mutate(sum_cost = sum(costin_pf)) %>% 
  mutate(sum_cpd = sum(cost.pf)) %>% 
  mutate(n=n()) %>% 
  ungroup(age_group) %>% 
  mutate(avg_cost = sum_cost / n) %>% 
  mutate(avg_cpd = sum_cpd / n) %>% 
  distinct(age_group,avg_cost,avg_cpd,n)
plt <- ggplot(data=pltdat)+
  geom_bar(aes(x=age_group,y=avg_cost),stat = "identity") +
  labs(y="Total average cost",x="Age group")+
  theme(text = element_text(size=50))
ggplot(data=pltdat)+
  geom_bar(aes(x=age_group,y=avg_cpd),stat = "identity")
ggsave(plt,file=paste0("inspect_agegrp_tcost.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

# male vs cost
pltdat <- surv_long2 %>% filter(vst==0) %>% select(id,vst,male,costin_pf,costin_pp)

pltdat <- pltdat %>% 
  group_by(male) %>% 
  mutate(sumcost = sum(costin_pf)) %>% 
  mutate(n = n()) %>% 
  mutate(sd = sd(costin_pf)) %>% 
  ungroup(male) %>% 
  mutate(avg_cost = sumcost/n) %>% 
  mutate(lci = avg_cost - 1.96*(sd/sqrt(n))) %>% 
  mutate(uci = avg_cost + 1.96*(sd/sqrt(n))) %>% 
  distinct(male,avg_cost,lci,uci) %>% 
  mutate(maletxt = if_else(male==0,"female",
                           if_else(male==1,"male","NA")) )

plt <- ggplot()+
  geom_point(data=pltdat,aes(x=maletxt,y=avg_cost),size=4) +
  geom_errorbar(data=pltdat,aes(x = maletxt,ymin=lci,ymax=uci),size=2) +
  labs(y="Average Total Cost",x="Gender")+
  theme(text = element_text(size=50))
ggsave(plt,file=paste0("inspect_malecost.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

# t_ vs cost
pltdat <- surv_long2 %>% filter(vst==0) %>% select(id,vst,t_,costin_pf,costin_pp)

pltdat <- pltdat %>% 
  group_by(t_) %>% 
  mutate(sumcost = sum(costin_pf)) %>% 
  mutate(n = n()) %>% 
  mutate(sd = sd(costin_pf)) %>% 
  ungroup(t_) %>% 
  mutate(avg_cost = sumcost/n) %>% 
  mutate(lci = avg_cost - 1.96*(sd/sqrt(n))) %>% 
  mutate(uci = avg_cost + 1.96*(sd/sqrt(n))) %>% 
  distinct(t_,avg_cost,lci,uci) %>% 
  mutate(Txtxt = if_else(t_==0,"NoTx",
                         if_else(t_==1,"Tx","NA")) )

plt <- ggplot()+
  geom_point(data=pltdat,aes(x=Txtxt,y=avg_cost),size=4) +
  geom_errorbar(data=pltdat,aes(x = Txtxt,ymin=lci,ymax=uci),size=2) +
  labs(y="Average total cost",x="Treatment")+
  theme(text = element_text(size=50))
ggsave(plt,file=paste0("inspect_txcost.png"), width =  1200, height = 210 , units = "mm", dpi = 300)



# inspect cost pp ---------------------------------------------------------

surv_long2 %>% filter(vst==0) %>% select(id,vst,costin_pf,costin_pp) 

summary(surv_long2 %>% filter(vst==0) %>% select(id,vst,costin_pf,costin_pp) %>% pull(costin_pf) )
summary(surv_long2 %>% filter(vst==0 & t_==0) %>% select(id,vst,costin_pf,costin_pp) %>% pull(costin_pf) )


# age vs costs
#  & is.na(costin_pp)==F means in prog state
surv_long2 %>% filter(vst==0) %>% select(id,vst,age,costin_pp,costin_pp)

plt <- ggplot(data=surv_long2 %>% filter(vst==0))+
  geom_point(aes(x=age,y=costin_pp),alpha=0.2) +
  labs(y="Total Cost",x="Age")+
  theme(text = element_text(size=60))
ggsave(plt,file=paste0("inspect_agecost_pp.png"), width =  1200, height = 210 , units = "mm", dpi = 300)


# male vs cost
pltdat <- surv_long2 %>% filter(vst==0 & is.na(costin_pp)==F) %>% select(id,vst,male,costin_pp,costin_pp)

pltdat <- pltdat %>% 
  group_by(male) %>% 
  mutate(sumcost = sum(costin_pp,na.rm=T)) %>% 
  mutate(n = n()) %>% 
  mutate(sd = sd(costin_pp,na.rm=T)) %>% 
  ungroup(male) %>% 
  mutate(avg_cost = sumcost/n) %>% 
  mutate(lci = avg_cost - 1.96*(sd/sqrt(n))) %>% 
  mutate(uci = avg_cost + 1.96*(sd/sqrt(n))) %>% 
  distinct(male,avg_cost,lci,uci) %>% 
  mutate(maletxt = if_else(male==0,"female",
                           if_else(male==1,"male","NA")) )

plt <- ggplot()+
  geom_point(data=pltdat,aes(x=maletxt,y=avg_cost),size=4) +
  geom_errorbar(data=pltdat,aes(x = maletxt,ymin=lci,ymax=uci),size=2) +
  labs(y="Average Total Cost",x="Gender")+
  theme(text = element_text(size=50))
ggsave(plt,file=paste0("inspect_malecost_pp.png"), width =  1200, height = 210 , units = "mm", dpi = 300)

# t_ vs cost
pltdat <- surv_long2 %>% filter(vst==0 & is.na(costin_pp)==F) %>% select(id,vst,t_,costin_pp,costin_pp)

pltdat <- pltdat %>% 
  group_by(t_) %>% 
  mutate(sumcost = sum(costin_pp)) %>% 
  mutate(n = n()) %>% 
  mutate(sd = sd(costin_pp)) %>% 
  ungroup(t_) %>% 
  mutate(avg_cost = sumcost/n) %>% 
  mutate(lci = avg_cost - 1.96*(sd/sqrt(n))) %>% 
  mutate(uci = avg_cost + 1.96*(sd/sqrt(n))) %>% 
  distinct(t_,avg_cost,lci,uci) %>% 
  mutate(Txtxt = if_else(t_==0,"NoTx",
                         if_else(t_==1,"Tx","NA")) )

plt <- ggplot()+
  geom_point(data=pltdat,aes(x=Txtxt,y=avg_cost),size=4) +
  geom_errorbar(data=pltdat,aes(x = Txtxt,ymin=lci,ymax=uci),size=2) +
  labs(y="Average total cost",x="Treatment")+
  theme(text = element_text(size=50))
ggsave(plt,file=paste0("inspect_txcost_pp.png"), width =  1200, height = 210 , units = "mm", dpi = 300)
