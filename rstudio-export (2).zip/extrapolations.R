
# extrapolate the flexsurv models on with KM curves

t <- seq(0,10,by=0.01) # used in plot


# to prog
# adjusted weighted - trans to prog
survmodtx <- survfit(Surv(Tstart,Tstop,status_p) ~ 1,
                       data = tevents_weights,weights = iptw)

#unadj_surv <- summary(survmodtx,times = t)
adj_surv <- summary(survmodtx,times = t)
#as.data.frame(adj_surv)

my.list <- summary(trans_toprog_mod, t=t)[[1]]

ggplot() +
  geom_line(data = my.list, aes(x=time,y = est),size= 0.9,alpha=0.7,colour="red") +
  geom_line( aes(x=adj_surv$time,y = adj_surv$surv),size= 0.9,alpha=0.7,colour="blue") 


survmodtx_0 <- survfit(Surv(Tstart,Tstop,status_p) ~ 1,
                       data = tevents_weights %>% filter(t_==0),weights = iptw)
survmodtx_1 <- survfit(Surv(Tstart,Tstop,status_p) ~ 1,
                       data = tevents_weights %>% filter(t_==1),weights = iptw)

#unadj_surv <- summary(survmodtx,times = t)
adj_surv_0 <- summary(survmodtx_0,times = t)
adj_surv_1 <- summary(survmodtx_1,times = t)

trans_toprog_mod_0 <- flexsurvreg(Surv(Tstart,Tstop,status_p) ~ age + t_ + v_,
                                data = tevents_weights %>% filter(t_==0) , dist="weibull",weights = iptw)
trans_toprog_mod_1 <- flexsurvreg(Surv(Tstart,Tstop,status_p) ~ age + t_ + v_,
                                data = tevents_weights %>% filter(t_==1) , dist="weibull",weights = iptw)
fs_0 <- summary(trans_toprog_mod_0, t=t)[[1]]
fs_1 <- summary(trans_toprog_mod_1, t=t)[[1]]

plt <- ggplot()+
  geom_line(aes(x=adj_surv_0$time,y=adj_surv_0$surv),colour="black",linewidth=4,alpha=0.5) +
  geom_line(aes(x=adj_surv_1$time,y=adj_surv_1$surv),colour="azure4",linewidth=4,alpha=0.5)+
  geom_line(aes(x=fs_0$time,y=fs_0$est),colour="black",linewidth=2.7) +
  geom_line(aes(x=fs_1$time,y=fs_1$est),colour="azure4",linewidth=2.7,linetype=2) +
  theme(text = element_text(size=50)) +
  labs(y = "survival",x = "years") 
ggsave(plt,file="toprog_extrapolate.png", width =  600, height = 290 , units = "mm", dpi = 300)  

# to death all

# adjusted weighted - trans to death
survmodtx <- survfit(Surv(Tstart,Tstop,status_d) ~ 1,
                     data = tevents_weights,weights = iptw)

adj_surv <- summary(survmodtx,times = t)

my.list <- summary(trans_todeath_mod, t=t)[[1]]

plt <- ggplot() +
  geom_line(data = my.list, aes(x=time,y = est),size= 2.7,alpha=0.9,colour="black") +
  geom_line( aes(x=adj_surv$time,y = adj_surv$surv),size= 4,alpha=0.7,colour="azure4") +
  theme(text = element_text(size=50)) +
  labs(y = "survival",x = "years") 
ggsave(plt,file="todeath_extrapolate.png", width =  600, height = 290 , units = "mm", dpi = 300)  

# todeath  by tx group
survmodtx_0 <- survfit(Surv(Tstart,Tstop,status_d) ~ 1,
                       data = tevents_weights %>% filter(t_==0),weights = iptw)
survmodtx_1 <- survfit(Surv(Tstart,Tstop,status_d) ~ 1,
                       data = tevents_weights %>% filter(t_==1),weights = iptw)

#unadj_surv <- summary(survmodtx,times = t)
adj_surv_0 <- summary(survmodtx_0,times = t)
adj_surv_1 <- summary(survmodtx_1,times = t)

trans_todeath_mod_0 <- flexsurvreg(Surv(Tstart,Tstop,status_d) ~ age + male + v_,
                                  data = tevents_weights %>% filter(t_==0) , dist="weibull",weights = iptw)
trans_todeath_mod_1 <- flexsurvreg(Surv(Tstart,Tstop,status_d) ~ age + male + v_,
                                  data = tevents_weights %>% filter(t_==1) , dist="weibull",weights = iptw)
fs_0 <- summary(trans_todeath_mod_0, t=t)[[1]]
fs_1 <- summary(trans_todeath_mod_1, t=t)[[1]]

plt <- ggplot()+
  geom_line(aes(x=adj_surv_0$time,y=adj_surv_0$surv),colour="red") +
  geom_line(aes(x=adj_surv_1$time,y=adj_surv_1$surv),colour="blue")+
  geom_line(aes(x=fs_0$time,y=fs_0$est),colour="red") +
  geom_line(aes(x=fs_1$time,y=fs_1$est),colour="blue")
ggsave(plt,file="todeath_extrapolatetx.png")  



