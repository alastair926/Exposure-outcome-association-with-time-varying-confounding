
surv_wide

# overall death
temp <- surv_wide %>% select(id,Tstop=real_dead_t,dead_s,age,male,costin_pf,costin_pp,cost.pf,cost.pp)
t_events<-sort(unique(temp$Tstop))
times<-data.frame("tevent"=t_events,"ID_t"=seq(1:length(t_events)))


splitoverall <- survSplit(temp, cut=t_events, end="Tstop", start="Tstart",
                         event="dead_s",id="ID") #start="Tstart"
splitoverall<-splitoverall[order(splitoverall$ID,splitoverall$Tstop ),] 


# attach time varying confounders
# create time varying covariate lookup
# baseline vst date
tv_lu <- surv_long3 %>% #here
  select(id,vst , t_, v_) %>%
  mutate(vsttime = vst*timeinterval)


t_events
# I need to make lu on tevents being key, then flag closest t_base_vst to t_events
tevents_overall <- splitoverall %>% select(id,Tstart,Tstop,dead_s,age,male)
tevents_overall <- merge(tevents_overall,tv_lu,by="id",all.x = T)
tevents_overall <- tevents_overall %>%
  filter(vsttime <= Tstart) %>%
  group_by(id,Tstart) %>%
  mutate(tempmax = max(vsttime)) %>%
  ungroup(id,Tstart) %>%
  filter(tempmax == vsttime) %>% 
  arrange(id,Tstart) 



# weights

w <- ipwtm(exposure = t_, family = "binomial",
           link = "logit",
           numerator = ~ age + male  ,
           denominator = ~ age + male + v_,
           id = id,
           timevar = Tstop, type = "first", data = as.data.frame(tevents_overall))

iptw = w$ipw.weights

tevents_overall <- cbind(tevents_overall, iptw)



ipwplot(weights = tevents_overall$iptw, 
        timevar = as.numeric(tevents_overall$Tstop), 
        binwidth = 0.5,
        main = "Stabilized weights", 
        # xaxt = "n",
        # yaxt = "n",
        xlab = "Every 6 months",
        ylab = "Log(Weights)")


# surv curves
# adjusted weighted - trans to death only (NOT OVERALL SURV)
survmodtx_0 <- survfit(Surv(Tstart,Tstop,dead_s) ~ 1,
                       data = tevents_overall %>% filter(t_==0)) #,weights = iptw
survmodtx_1 <- survfit(Surv(Tstart,Tstop,dead_s) ~ 1,
                       data = tevents_overall %>% filter(t_==1))

t <- seq(0,3.5,by=0.1)
#unadj_surv <- summary(survmodtx,times = t)
adj_surv_0 <- summary(survmodtx_0,times = t)
adj_surv_1 <- summary(survmodtx_1,times = t)
plt <- ggplot()+
  geom_line(aes(x=adj_surv_0$time,y=adj_surv_0$surv),colour="black",linewidth=2.7) +
  geom_line(aes(x=adj_surv_1$time,y=adj_surv_1$surv),colour="azure4",linetype=2,linewidth=2.7) +
  # geom_line(aes(x=fs_0$time,y=fs_0$est),colour="red",linewidth=2.7) +
  # geom_line(aes(x=fs_1$time,y=fs_1$est),colour="blue",linewidth=2.7) +
  theme(text = element_text(size=50)) +
  labs(y = "survival",x = "years") 
ggsave(plt,file="overall_SC.png", width =  600, height = 290 , units = "mm", dpi = 300)  


# flexsurv tx effect
overall_mod <- flexsurvreg(Surv(Tstart,Tstop,dead_s) ~ age + male + t_ + v_,
                                 data = tevents_overall , dist="weibull",weights = iptw)

plot(overall_mod)

save(overall_mod,file="overall_mod.RData")




