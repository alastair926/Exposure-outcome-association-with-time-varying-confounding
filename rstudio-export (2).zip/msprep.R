



# msprep ------------------------------------------------------------------


surv_wide <- surv_long3 %>%  
  select(-c(iptw)) %>% 
  pivot_wider(
    names_from = vst,
    values_from = c(t_, v_ , eq5d_pf_ , eq5d_pp_)
  )


surv_wide <- surv_wide %>% 
  # max fup
  mutate(real_dead_t = if_else( is.na(real_dead_t) & dead_s == 0 , fup_array[timepoints] , real_dead_t )) %>% 
  # msprep format
  mutate(real_prog_t = if_else( prog_s == 0 , real_dead_t , real_prog_t))


surv_wide$id <- as.factor(surv_wide$id)

tmat <- trans.illdeath()
alltransdata <- msprep(time=c(NA,"real_prog_t","real_dead_t"),status=c(NA,"prog_s","dead_s"),data=as.data.frame(surv_wide),
       id="id",trans=tmat) #keep=c("age","male","costin_pf","costin_pp","cost.pf","cost.pp")) # 
nrow(alltransdata)

alltransdata <- merge(alltransdata,surv_wide %>% distinct(id,age,male,costin_pf,costin_pp,cost.pf,cost.pp),by="id",all.x = T)

save(alltransdata,file = "alltransdata.RData")
save(surv_wide,file = "surv_wide.RData")




