

# add on baseline and time varying covariates 

# shift time by one  - first row for each individual has -1 time tstart
splitdata$tstart <- tstartfun(id, Tstart, splitdata)



# create time varying covariate lookup
# baseline vst date
tv_lu <- surv_long3 %>% #here
  select(id,vst , t_, v_) %>%
  mutate(vsttime = vst*timeinterval)

surv_long3 %>% select(id,vst,t_) %>% filter(id==5)
t_events
# I need to make lu on tevents being key, then flag closest t_base_vst to t_events
tevents_dat <- splitdata %>% select(id,tstart,Tstart,Tstop,status_p,status_d,age,male)
tevents_dat <- merge(tevents_dat,tv_lu,by="id",all.x = T)
tevents_dat <- tevents_dat %>%
  filter(vsttime <= Tstart) %>%
  group_by(id,Tstart) %>%
  mutate(tempmax = max(vsttime)) %>%
  ungroup(id,Tstart) %>%
  filter(tempmax == vsttime) %>% 
  arrange(id,Tstart) 




save(tevents_dat,file = "tevent_dat.RData")
