


survmodtx_0 <- survfit(Surv(Tstart,Tstop,status_d) ~ 1,
                       data = tevents_weights %>% filter(t_==0),weights = iptw)
survmodtx_1 <- survfit(Surv(Tstart,Tstop,status_d) ~ 1,
                       data = tevents_weights %>% filter(t_==1),weights = iptw)

trans_toprog_mod <- flexsurvreg(Surv(Tstart,Tstop,status_p) ~ age + t_ + v_,
            data = tevents_weights , dist="weibull",weights = iptw)
trans_todeath_mod <- flexsurvreg(Surv(Tstart,Tstop,status_d) ~ age + male + v_,
            data = tevents_weights , dist="weibull",weights = iptw)
# flexsurvreg(Surv(Tstart,Tstop,status_d) ~ age + male + v_,
#             data = tevents_weights , dist="weibull")
# flexsurvreg(Surv(Tstart,Tstop,status_d) ~ age + male + v_ + t_,
#             data = tevents_weights , dist="weibull",weights = iptw)

save(trans_todeath_mod,trans_toprog_mod,file="transitionmodels.RData")

